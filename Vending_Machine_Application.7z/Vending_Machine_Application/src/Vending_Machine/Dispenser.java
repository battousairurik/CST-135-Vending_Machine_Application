package Vending_Machine;

import java.util.ArrayList;

public class Dispenser
{
	private ArrayList<Product> stockedProducts = new ArrayList<>();
	private double cashInMachine;
	private boolean isStocked;
	/* These two fields will be included when the Customer and Boss classes are created
	private Customer customerAccess;
	private Boss bossAccess;
	*/

	public Dispenser()
	{
		stockMachineDefault();
	}
	
	private void stockMachineDefault()
	{
		stockedProducts.add(new Candy("Gummy Bears", 2.00, 0, 8, "A1", "Haribo", false));
		stockedProducts.add(new Candy("Red Licorice", 2.50, 1, 10, "A2", "Red Vines", false));
		stockedProducts.add(new Candy("Skittles", 1.50, 2, 12, "A3", "Wrigley Company", false));
		stockedProducts.add(new Candy("Nerds", 1.50, 3, 7, "A4", "Nestle", false));
		stockedProducts.add(new Candy("Sour Patch Kids", 2.00, 4, 8, "A5", "Hershey", false));
		stockedProducts.add(new Candy("Twix", 1.50, 5, 12, "B1", "Mars", true));
		stockedProducts.add(new Candy("Snickers", 1.50, 6, 10, "B2", "Mars", true));
		stockedProducts.add(new Candy("Crunch", 1.50, 7, 11, "B3", "Nestle", true));
		stockedProducts.add(new Candy("Kit Kat", 1.75, 8, 12, "B4", "Nestle", true));
		stockedProducts.add(new Candy("Reese's PB Cups", 2.00, 9, 10, "B5", "Hershey", true));
	}

	public void displayProducts()
	{
		for (Product product : stockedProducts)
		{
			System.out.println(product.toString() + "\r\n");
		}
	}
	
	protected void viewStock()
	{
		
	}
	
	protected void disableMachine()
	{
		
	}
	
	private void setCustomerAccess()
	{
		
	}
	
	public void customerLogin()
	{
		
	}
	
	public void acceptPayment(double payment)
	{
		
	}
	
	public double dispenseChange()
	{
		// Placeholder
		return 0;		
	}
	
	public Product dispenseProduct(String input)
	{
		// Placeholder
		return null;
	}
	
	private void setBossAccess()
	{
		
	}
	
	public void bossLogin(String password)
	{
		
	}
	
	public void stockProduct()
	{
		
	}
	
	public void withdrawCash(double withdraw)
	{
		
	}
	
	public void depositCash(double deposit)
	{
		
	}
	
	public void setProductPrice(double price)
	{
		
	}
}
