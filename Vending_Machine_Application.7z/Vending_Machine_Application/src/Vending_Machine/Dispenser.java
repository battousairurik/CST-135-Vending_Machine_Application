package Vending_Machine;

import java.util.ArrayList;

public class Dispenser
{
	private ArrayList<Product> stockedProducts = new ArrayList<>();
	private double cashInMachine;
	private boolean isStocked;
	
	/* These two fields will be included when the Customer and Boss classes are created
	private Customer customerAccess;
	private Boss bossAccess;
	*/

	public Dispenser()
	{
		stockMachineDefault();
	}
	
	private void stockMachineDefault()
	{
		stockedProducts.add(new Candy("Gummy Bears", 2.00, 0, 8, "A1", "Haribo", false));
		stockedProducts.add(new Candy("Red Licorice", 2.50, 1, 10, "A2", "Red Vines", false));
		stockedProducts.add(new Candy("Skittles", 1.50, 2, 12, "A3", "Wrigley Company", false));
		stockedProducts.add(new Candy("Nerds", 1.50, 3, 7, "A4", "Nestle", false));
		stockedProducts.add(new Candy("Sour Patch Kids", 2.00, 4, 8, "A5", "Hershey", false));
		stockedProducts.add(new Candy("Twix", 1.50, 5, 12, "B1", "Mars", true));
		stockedProducts.add(new Candy("Snickers", 1.50, 6, 10, "B2", "Mars", true));
		stockedProducts.add(new Candy("Crunch", 1.50, 7, 11, "B3", "Nestle", true));
		stockedProducts.add(new Candy("Kit Kat", 1.75, 8, 12, "B4", "Nestle", true));
		stockedProducts.add(new Candy("Reese's PB Cups", 2.00, 9, 10, "B5", "Hershey", true));
		stockedProducts.add(new Chips("Doritos", 	2.00, 10, 10, "C1", "Frito-Lay", "Nacho Cheese"));
		stockedProducts.add(new Chips("Fritos", 	2.00, 11, 8, "C2", "Frito-Lay", "Original"));
		stockedProducts.add(new Chips("Lay's", 	2.00, 12, 10, "C3", "Frito-Lay", "Classic"));
		stockedProducts.add(new Chips("Lay's", 	2.00, 13, 9, "C4", "Frito-Lay", "Bar-B-Q"));
		stockedProducts.add(new Chips("Lay's", 	2.00, 14, 8, "C5", "Frito-Lay", "Salt & Vinegar"));
		stockedProducts.add(new Gum("Juicy Fruit", 1.00, 15, 15, "D1", "Wrigley Company", false));
		stockedProducts.add(new Gum("Spearmint", 1.00, 16, 12, "D2", "Wrigley Company", false));
		stockedProducts.add(new Gum("Trident Original", 1.00, 17, 15, "D3", "Cadbury", false));
		stockedProducts.add(new Gum("Big Red", 1.00, 18, 12, "D4", "Wrigley Company", false));
		stockedProducts.add(new Gum("Stride Winter Blue", 1.00, 19, 12, "D5", "Cadbury", true));
		stockedProducts.add(new Drink("Coca-Cola", 0.75, 20, 8, "E1", "Coca-Cola Company", 1));
		stockedProducts.add(new Drink("Diet Coke", 0.75, 21, 8, "E2", "Coca-Cola Company", 1));
		stockedProducts.add(new Drink("Dr Pepper", 0.75, 22, 8, "E3", "Dr Pepper Snapple Group", 1));
		stockedProducts.add(new Drink("A&W Root Beer", 0.75, 23, 8, "E4", "Dr Pepper Snapple Group", 1));
		stockedProducts.add(new Drink("Sprite", 0.75, 24, 8, "E5", "Coca-Cola Company", 1));
	}

	public void displayProducts()
	{
		for (Product product : stockedProducts)
		{
			System.out.println(product.toString() + "\r\n");
		}
	}
	
	protected void viewStock()
	{
		
	}
	
	protected void disableMachine()
	{
		
	}
	
	private void setCustomerAccess()
	{
		
	}
	
	public void customerLogin()
	{
		
	}
	
	public void acceptPayment(double payment)
	{
		
	}
	
	public double dispenseChange()
	{
		// Placeholder
		return 0;		
	}
	
	public Product dispenseProduct(String input)
	{
		// Placeholder
		return null;
	}
	
	private void setBossAccess()
	{
		
	}
	
	public void bossLogin(String password)
	{
		
	}
	
	public void stockProduct()
	{
		
	}
	
	public void withdrawCash(double withdraw)
	{
		
	}
	
	public void depositCash(double deposit)
	{
		
	}
	
	public void setProductPrice(double price)
	{
		
	}

	// Get product by index
	public Product getStockedProduct(int index)
	{
		if (index >= 0 && index < stockedProducts.size())
			return stockedProducts.get(index);
		else
			return null;
	}

	// Get product by name
	public Product getStockedProduct(String productName)
	{
		// Iterate through all products in ArrayList
		// Find String match for product name
		for (Product product : stockedProducts)
		{
			if (product.getProductName().equals(productName))
			{
				return product;
			}
		}
		
		// Name not found
		return null;
	}
}
