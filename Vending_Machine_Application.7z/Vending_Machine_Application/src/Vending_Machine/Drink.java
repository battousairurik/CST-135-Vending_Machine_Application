package Vending_Machine;

public class Drink extends Product{

	private String drinkBrand;
	private int drinkSize;
	
	public Drink()
	{
		setProductName("");
		setProductPrice(0.0);
		setProductID(-1);
		setProductAmount(0);
		setProductLocation("");
		drinkBrand = "";
		drinkSize = 0;
		setIsStocked(false);
	}
	public Drink (String name, Double price, int ID, int amount, String location, String brand, int size){
		setProductName(name);
		setProductPrice(price);
		setProductID(ID);
		setProductAmount(amount);
		setProductLocation(location);
		drinkBrand = brand;
		drinkSize = size;
		if (amount > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
	}
	
	// Copy constructor
	public Drink (Drink someDrink){
		setProductName(someDrink.getProductName());
		setProductPrice(someDrink.getProductPrice());
		setProductID(someDrink.getProductID());
		setProductAmount(someDrink.getProductAmount());
		setProductLocation(someDrink.getProductLocation());
		drinkBrand = someDrink.getDrinkBrand();
		drinkSize = someDrink.getDrinkSize();
		setIsStocked(someDrink.getIsStocked());
	}

	public void setDrinkBrand(String brand){
		drinkBrand = brand;
	}
	public String getDrinkBrand (){
		return drinkBrand;
	}
	public void setDrinkSize (int size){
		drinkSize = size;
	}
	public int getDrinkSize (){
		return drinkSize;
	}
	@Override
	public String toString(){
		return "Product: " + getProductName()
				+ "\nPrice: " + getProductPrice()
				+ "\nID: " + getProductID()
				+ "\nAmount: " + getProductAmount()
				+ "\nLocation: " + getProductLocation()
				+ "\nBrand: " + getDrinkBrand()
				+ "\nSize: " + getDrinkSize()
				+ "\nStocked: " + getIsStocked();
	}
}
