package Vending_Machine;

public class Drink extends Product  implements Comparable<Drink>{

	private String drinkBrand;
	private int drinkSize;
	
	//Default Constructor
	public Drink()
	{
		setProductName("");
		setProductPrice(0.0);
		setProductID(-1);
		setProductAmount(0);
		setProductLocation("");
		setDrinkBrand("");
		setDrinkSize(0);
		setIsStocked(false);
	}
	// Constructor to input data manually
	public Drink (String name, Double price, int ID, int amount, String location, String brand, int size){
		setProductName(name);
		setProductPrice(price);
		setProductID(ID);
		setProductAmount(amount);
		setProductLocation(location);
		setDrinkBrand(brand);
		setDrinkSize(size);
		if (amount > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
	}
	// Copy constructor
	public Drink (Drink someDrink){
		setProductName(someDrink.getProductName());
		setProductPrice(someDrink.getProductPrice());
		setProductID(someDrink.getProductID());
		setProductAmount(someDrink.getProductAmount());
		setProductLocation(someDrink.getProductLocation());
		drinkBrand = someDrink.getDrinkBrand();
		drinkSize = someDrink.getDrinkSize();
		setIsStocked(someDrink.getIsStocked());
	}

	public void setDrinkBrand(String brand){
		drinkBrand = brand;
	}
	public String getDrinkBrand (){
		return drinkBrand;
	}
	public void setDrinkSize (int size){
		drinkSize = size;
	}
	public int getDrinkSize (){
		return drinkSize;
	}
	// toString method to list all elements
	@Override
	public String toString(){
		return "Product: " + getProductName()
				+ "\nPrice: " + getProductPrice()
				+ "\nID: " + getProductID()
				+ "\nAmount: " + getProductAmount()
				+ "\nLocation: " + getProductLocation()
				+ "\nBrand: " + getDrinkBrand()
				+ "\nSize: " + getDrinkSize()
				+ "\nStocked: " + getIsStocked();
	}
	@Override
	public int compareTo(Drink o) {
		// First check to see if the starting letter of each word are the same
				if (this.getProductName().charAt(0) != o.getProductName().charAt(0))
					return this.getProductName().compareTo(o.getProductName());
				// If two words with the same starting letter match, then compare by price
				else if (this.getProductName().charAt(0) == o.getProductName().charAt(0)){
					if (this.getProductPrice() > o.getProductPrice())
						return 1;
					else if (this.getProductPrice() < o.getProductPrice())
						return -1;
					else if (this.getProductPrice() == o.getProductPrice())
						//Final comparison based upon location if both name and price are identical
						return this.getProductLocation().compareTo(o.getProductLocation());
					// Final else statement to prevent compile errors
					else
						return 0;
				}
				// Final else statement to prevent compile errors
				else
					return 0;
	}
	
}
