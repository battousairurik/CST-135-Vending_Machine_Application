package Vending_Machine;

public abstract class Snack extends Product{

	private String snackBrand;
	
	public Snack () {};
	public Snack (String name, Double price, int ID, int amount, String location, String brand){
		setProductName(name);
		setProductPrice(price);
		setProductID(ID);
		setProductAmount(amount);
		setProductLocation(location);
		snackBrand = brand;
		if (amount > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
	}
	public Snack (Snack someSnack){
		
	}
	public void setSnackBrand (String brand){
		snackBrand = brand;
	}
	public String getSnackBrand (){
		return snackBrand;
	}
	
	//toString methods needed on the subclasses only?
}
