package Vending_Machine;

public abstract class Snack extends Product implements Comparable<Snack>{

	private String snackBrand;
	
	// Default blank constructor
	public Snack () {
		setProductName(" ");
		setProductPrice(0.0);
		setProductID(-1);
		setProductAmount(0);
		setProductLocation(" ");
		setSnackBrand(" ");
		setIsStocked(false);
	}
	// Constructor for manual input
	public Snack (String name, Double price, int ID, int amount, String location, String brand){
		setProductName(name);
		setProductPrice(price);
		setProductID(ID);
		setProductAmount(amount);
		setProductLocation(location);
		setSnackBrand(brand);
		if (amount > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
	}

	// No need for copy constructor as this is an abstract class
	
	public void setSnackBrand (String brand){
		snackBrand = brand;
	}
	public String getSnackBrand (){
		return snackBrand;
	}
	// toString method to list all product information
	@Override
	public String toString(){
		return "Product: " + getProductName()
		+ "\nPrice: " + getProductPrice()
		+ "\nID: " + getProductID()
		+ "\nAmount: " + getProductAmount()
		+ "\nLocation: " + getProductLocation()
		+ "\nBrand: " + getSnackBrand()
		+ "\nStocked: " + getIsStocked();
	}
	@Override
	public int compareTo(Snack o) {
		// First check to see if the starting letter of each word are the same
		if (this.getProductName().charAt(0) != o.getProductName().charAt(0))
			return this.getProductName().compareTo(o.getProductName());
		// If two words with the same starting letter match, then compare by price
		else if (this.getProductName().charAt(0) == o.getProductName().charAt(0)){
			if (this.getProductPrice() > o.getProductPrice())
				return 1;
			else if (this.getProductPrice() < o.getProductPrice())
				return -1;
			else if (this.getProductPrice() == o.getProductPrice())
				//Final comparison based upon location if both name and price are identical
				return this.getProductLocation().compareTo(o.getProductLocation());
			// Final else statement to prevent compile errors
			else
				return 0;
		}
		// Final else statement to prevent compile errors
		else
			return 0;
	}
}
