package Vending_Machine;

public abstract class Snack extends Product{

	private String snackBrand;
	
	public Snack () {};
	public Snack (String name, Double price, int ID, int amount, String location, String brand){
		setProductName(name);
		setProductPrice(price);
		setProductID(ID);
		setProductAmount(amount);
		setProductLocation(location);
		snackBrand = brand;
		if (amount > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
	}

	// No need for copy constructor as this is an abstract class
	
	public void setSnackBrand (String brand){
		snackBrand = brand;
	}
	public String getSnackBrand (){
		return snackBrand;
	}
	
	@Override
	public String toString(){
		return "Product: " + getProductName()
		+ "\nPrice: " + getProductPrice()
		+ "\nID: " + getProductID()
		+ "\nAmount: " + getProductAmount()
		+ "\nLocation: " + getProductLocation()
		+ "\nBrand: " + getSnackBrand()
		+ "\nStocked: " + getIsStocked();
	}
}
