package Vending_Machine;

import javafx.application.Application;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class DispenserGUI extends Application{

	private Dispenser machine1 = new Dispenser();

	@Override
	public void start(Stage stage1) throws Exception {
		
		Button drinksBTN = new Button ("Drinks");
		Button candyBTN = new Button ("Candy");
		Button chipsBTN = new Button ("Chips");
		Button gumBTN = new Button ("Gum");
		
		Image drinksIMG = new Image ("");
		Image candyIMG = new Image ("");
		Image chipsIMG = new Image ("");
		Image gumIMG = new Image ("");
		
		GridPane gridPane = new GridPane();
		gridPane.getChildren().add(new ImageView(drinksIMG));
		gridPane.add(drinksBTN, 0, 1, 1, 1);
		gridPane.getChildren().add(new ImageView(candyIMG));
		gridPane.add(candyBTN, 1, 1, 1, 1);
		gridPane.getChildren().add(new ImageView(chipsIMG));
		gridPane.add(chipsBTN, 2, 1, 1, 1);
		gridPane.getChildren().add(new ImageView(gumIMG));
		gridPane.add(gumBTN, 3, 1, 1, 1);
	}
	
	
}
