package Vending_Machine;

import java.text.NumberFormat;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class DispenserGUI extends Application
{
	private Dispenser machine1 = new Dispenser();
	private animationHandling vend = new animationHandling();
	
	private Font font = new Font("Arial", 14);
	private Font fontBold = new Font("Arial Bold", 14);
	
	// To format $$ strings
	private NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();

	// Class variables
	Button drinksBTN;
	Button candyBTN;
	Button chipsBTN;
	Button gumBTN;
	
	// Start with $20
	TransactionProcessing transactions = new TransactionProcessing(20.00);
	
	public static void main(String[] args) {
        launch(args);
    }
	
	@Override
	public void start(Stage stage) throws Exception {
		
		stage.setTitle("Vending Machine Demo");
		stage.setWidth(350);
		stage.setHeight(200);
		
		Scene scene = new Scene(createMainScreen());
		updateScene(stage, scene);
	}
	
	public VBox createMainScreen(){
		VBox display = new VBox(10);
		
		Button selectionDisplay = new Button ("Selection by Category");
		selectionDisplay.setOnAction(e -> createSelectionGUI());
		
		Button fullDisplay = new Button ("Display all Inventory");
		fullDisplay.setOnAction(e -> displayAllInventory());
		
		Button animationTest = new Button ("Test Animation");
		animationTest.setOnAction(e -> vendTest());
		
		Button adjustStock = new Button ("Adjust Stock");
		adjustStock.setOnAction(e -> adjustStock());
		
		display.getChildren().addAll(selectionDisplay, fullDisplay, animationTest, adjustStock);
		display.setPadding(new Insets(15, 15, 15, 15));
		
		display.setAlignment(Pos.CENTER);
		
		return display;
	}
	
	private void adjustStock()
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("Adjust Stock");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		Scene scene = new Scene(populateAdjustStockGridPane());
		updateScene(stage, scene);
	}
	
	private void createSelectionGUI(){
		Stage stage = new Stage();
		
		drinksBTN = new Button ("Drinks");
		candyBTN = new Button ("Candy");
		chipsBTN = new Button ("Chips");
		gumBTN = new Button ("Gum");
		
		Image drinksIMG = new Image("drinks.jpg");
		Image candyIMG = new Image("candy.jpg");
		Image chipsIMG = new Image("chips.png");
		Image gumIMG = new Image("gum.jpg");

		ImageView imageViewDrinks = new ImageView(drinksIMG);
		ImageView imageViewCandy = new ImageView(candyIMG);
		ImageView imageViewChips = new ImageView(chipsIMG);
		ImageView imageViewGum = new ImageView(gumIMG);
		
		ImageView pic = new ImageView();
		pic.setFitHeight(50);
		pic.setFitWidth(50);
		
		GridPane gridPane = new GridPane();
		gridPane.setPadding(new Insets (10, 10, 10, 10));
		gridPane.setVgap(10);
		gridPane.setHgap(10);
		
		gridPane.add(imageViewDrinks, 0, 0);
		gridPane.add(drinksBTN, 0, 1);
		GridPane.setHalignment(drinksBTN, HPos.CENTER);
		
		gridPane.add(imageViewCandy, 1, 0);
		gridPane.add(candyBTN, 1, 1);
		GridPane.setHalignment(candyBTN, HPos.CENTER);
		
		gridPane.add(imageViewChips, 0, 2);
		gridPane.add(chipsBTN, 0, 3);
		GridPane.setHalignment(chipsBTN, HPos.CENTER);
		
		gridPane.add(imageViewGum, 1, 2);
		gridPane.add(gumBTN, 1, 3);
		GridPane.setHalignment(gumBTN, HPos.CENTER);
		
		//Original manner of handling action events
		drinksBTN.setOnAction(new InventoryManagement());
		candyBTN.setOnAction(new InventoryManagement());
		chipsBTN.setOnAction(new InventoryManagement());
		gumBTN.setOnAction(new InventoryManagement());
		
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		stage.setTitle("Product display by type");
		
		Scene scene = new Scene(gridPane);
		updateScene(stage, scene);
	}
	
	private void displayItems(String productType)
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		Scene scene = new Scene(populateProductsGridPane(productType, stage));
		updateScene(stage, scene);
	}
	
	private void displayAllInventory()
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("Inventory");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		Scene scene = new Scene(populateInventoryGridPane());
		updateScene(stage, scene);
	}
	
	private GridPane populateInventoryGridPane()
	{
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);
		
		// Will count up for each new item
		int rowCounter = 0;
		
		// gridPane headers
		Label labelHeaderName = new Label("Name");
		labelHeaderName.setFont(fontBold);
		Label labelHeaderLocation = new Label("Location");
		labelHeaderLocation.setFont(fontBold);
		Label labelHeaderPrice = new Label("Price");
		labelHeaderPrice.setFont(fontBold);
		Label labelHeaderQuantity = new Label("Quantity");
		labelHeaderQuantity.setFont(fontBold);
		
		gridPane.add(labelHeaderName, 0, rowCounter);
		gridPane.add(labelHeaderLocation, 1, rowCounter);
		gridPane.add(labelHeaderPrice, 2, rowCounter);
		gridPane.add(labelHeaderQuantity, 3, rowCounter);
		rowCounter++;
		
		for (int i = 0; i < machine1.getTotalNumberOfProducts(); i++)
		{
			// Create labels for name, location, price and quantity
			Label labelName = new Label(machine1.getStockedProduct(i).getProductName());
			labelName.setFont(font);
			Label labelLocation = new Label(machine1.getStockedProduct(i).getProductLocation());
			labelLocation.setFont(font);
			Label labelPrice = new Label(currencyFormatter.format(machine1.getStockedProduct(i).getProductPrice()));
			labelPrice.setFont(font);
			Label labelQuantity = new Label("" + machine1.getStockedProduct(i).getProductAmount());
			labelQuantity.setFont(font);

			// Add in items to gridPane
			gridPane.add(labelName, 0, rowCounter);
			gridPane.add(labelLocation, 1, rowCounter);
			gridPane.add(labelPrice, 2, rowCounter);
			gridPane.add(labelQuantity, 3, rowCounter);

			rowCounter++;
		}
		
		return gridPane;
	}
	
	private GridPane populateAdjustStockGridPane()
	{
		// Work in progress
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);
		
		ObservableList<String> listLocation = 
			    FXCollections.observableArrayList(
			    		"A1", "A2", "A3", "A4", "A5",
			    		"B1", "B2", "B3", "B4", "B5",
			    		"C1", "C2", "C3", "C4", "C5",
			    		"D1", "D2", "D3", "D4", "D5",
			    		"E1", "E2", "E3", "E4", "E5"
			    );
		
		ComboBox comboBoxLocation = new ComboBox(listLocation);
		comboBoxLocation.getSelectionModel().select(0);
		
		TextField textFieldName = new TextField(machine1.getStockedProduct(0).getProductName());
		textFieldName.setMaxWidth(120);
		// Make name read-only (for now)
		textFieldName.setDisable(true);
		
		TextField textFieldQuantity = new TextField("" + machine1.getStockedProduct(0).getProductAmount());
		textFieldQuantity.setMaxWidth(60);
		textFieldQuantity.setPromptText("Quantity");
		
		Button buttonSave = new Button("Save");
		
		// Update name and quantity text fields when new item is selected
		comboBoxLocation.setOnAction(e ->
		{
			int selection = comboBoxLocation.getSelectionModel().getSelectedIndex();
			String itemName = machine1.getStockedProduct(selection).getProductName();
			String itemQuantity = "" + machine1.getStockedProduct(selection).getProductAmount();
			textFieldName.setText(itemName);
			textFieldQuantity.setText(itemQuantity);
		});

		// Check for integer in quantity
		// Return from method if it fails
		buttonSave.setOnAction(e ->
		{
			String input = textFieldQuantity.getText();
			
			int selection = comboBoxLocation.getSelectionModel().getSelectedIndex();	
			int quantity = 0;
			
			try
			{
				quantity = Integer.parseInt(input);
				
				// Reject negative quantities
				if (quantity < 0)
					return;
				// Reject absurdly high quantities
				else if (quantity > 50)
					return;
			}
			catch (Exception exception)
			{
				return;
			}
			
			// Save new product quantity
			machine1.getStockedProduct(selection).setProductAmount(quantity);
		});
		
		gridPane.add(comboBoxLocation, 0, 0);
		gridPane.add(textFieldName, 1, 0);
		gridPane.add(textFieldQuantity, 2, 0);
		gridPane.add(buttonSave, 2, 1);	
		GridPane.setHalignment(buttonSave, HPos.RIGHT);
		
		return gridPane;
	}
	
	private void updateScene(Stage stage, Scene scene)
	{
		stage.setScene(scene);
		stage.show();
	}
	
	// Default the current selection to 0
	// Overloaded method so that other calls need not specify the current selection
	private GridPane populateProductsGridPane(String productType, Stage stage)
	{
		return populateProductsGridPane(productType, stage, 0); 
	}
	
	private GridPane populateProductsGridPane(String productType, Stage stage, int currentSelection)
	{
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);

		// Will count up for each new item
		int rowCounter = 0;
		
		// gridPane headers
		Label labelHeaderSelect = new Label("Select");
		labelHeaderSelect.setFont(fontBold);
		Label labelHeaderName = new Label("Name");
		labelHeaderName.setFont(fontBold);
		Label labelHeaderLocation = new Label("Location");
		labelHeaderLocation.setFont(fontBold);
		Label labelHeaderPrice = new Label("Price");
		labelHeaderPrice.setFont(fontBold);
		Label labelHeaderQuantity = new Label("Quantity");
		labelHeaderQuantity.setFont(fontBold);
		
		gridPane.add(labelHeaderSelect, 0, rowCounter);
		gridPane.add(labelHeaderName, 1, rowCounter);
		gridPane.add(labelHeaderLocation, 2, rowCounter);
		gridPane.add(labelHeaderPrice, 3, rowCounter);
		gridPane.add(labelHeaderQuantity, 4, rowCounter);
		rowCounter++;
		
		// Item selection radio buttons
		ArrayList<RadioButton> buyRadioButtons = new ArrayList<>();
		final ToggleGroup toggleGroup = new ToggleGroup();
		
		// Check for product type and populate grid
		switch (productType)
		{
		case "Gum":
			for (int i = 0; i < machine1.getTotalNumberOfProducts(); i++)
			{
				if (machine1.getStockedProduct(i) instanceof Gum)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(machine1.getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(machine1.getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(machine1.getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + machine1.getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);

					Rectangle placeHolder = new Rectangle();
					placeHolder.setWidth(20);
					placeHolder.setHeight(20);
					
					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					gridPane.add(placeHolder, 5, rowCounter);
					gridPane.add(new Text ("          "), 6, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		case "Drink":
			for (int i = 0; i < machine1.getTotalNumberOfProducts(); i++)
			{
				if (machine1.getStockedProduct(i) instanceof Drink)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(machine1.getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(machine1.getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(machine1.getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + machine1.getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);

					Rectangle placeHolder = new Rectangle();
					placeHolder.setWidth(20);
					placeHolder.setHeight(20);
					
					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					gridPane.add(placeHolder, 5, rowCounter);
					gridPane.add(new Text ("          "), 6, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		case "Chips":
			for (int i = 0; i < machine1.getTotalNumberOfProducts(); i++)
			{
				if (machine1.getStockedProduct(i) instanceof Chips)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(machine1.getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(machine1.getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(machine1.getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + machine1.getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);
					
					Rectangle placeHolder = new Rectangle();
					placeHolder.setWidth(20);
					placeHolder.setHeight(20);

					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					gridPane.add(placeHolder, 5, rowCounter);
					gridPane.add(new Text ("          "), 6, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		case "Candy":
			for (int i = 0; i < machine1.getTotalNumberOfProducts(); i++)
			{
				if (machine1.getStockedProduct(i) instanceof Candy)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(machine1.getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(machine1.getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(machine1.getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + machine1.getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);

					Rectangle placeHolder = new Rectangle();
					placeHolder.setWidth(20);
					placeHolder.setHeight(20);
					
					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					gridPane.add(placeHolder, 5, rowCounter);
					gridPane.add(new Text ("          "), 6, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		}
		
		// Because scene is updated after a purchase, the radio buttons are all unselected
		// This is to ensure the last purchased item is selected
		// The default currentSelection is 0 (the first item)
		for (int i = 0; i < buyRadioButtons.size(); i++)
		{
			if (i == currentSelection)
			{
				buyRadioButtons.get(i).setSelected(true);
				break;
			}
		}
		
		// Buy button
		Button buyBTN = new Button("Buy");
		gridPane.add(buyBTN, 0, rowCounter);
		buyBTN.setOnAction(e ->
		{
			for (int i = 0; i < buyRadioButtons.size(); i++)
			{
				// Check which radio button is selected
				if (buyRadioButtons.get(i).isSelected())
				{
					int selectedItem = Integer.parseInt(buyRadioButtons.get(i).getId());
					
					// Check if item is available
					if (machine1.getStockedProduct(selectedItem).getProductAmount() > 0)
					{
						machine1.getStockedProduct(selectedItem)
								.setProductAmount(machine1.getStockedProduct(selectedItem).getProductAmount() - 1);
						
						transactions.addTransaction(machine1.getStockedProduct(selectedItem));
					}
					
					// updateScene method to reflect live quantity counts
					// Variable "i" is passed in as the currently selected item
					updateScene(stage, new Scene(populateProductsGridPane(productType, stage, i)));
					
					// Only one radio button can be selected
					// No need to continue loop after this point
					break;
				}
			}
		});
		

		// Done button
		Button doneBTN = new Button("Done");
		gridPane.add(doneBTN, 4, rowCounter);
		doneBTN.setOnAction(e -> displayTransactions(transactions));
		gridPane.add(new Rectangle (40, 20), 6, rowCounter);
		
		rowCounter++;
		
		return gridPane;
	}
	
	private void displayTransactions(TransactionProcessing transactions)
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		Scene scene = new Scene(populateTransactionsGridPane(transactions));
		updateScene(stage, scene);
	}
	
	private GridPane populateTransactionsGridPane(TransactionProcessing transactions)
	{
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);

		// Will count up for each new item
		int rowCounter = 0;
		
		// gridPane headers
		Label labelHeaderName = new Label("Name");
		labelHeaderName.setFont(fontBold);
		Label labelHeaderPrice= new Label("Price");
		labelHeaderPrice.setFont(fontBold);
		
		gridPane.add(labelHeaderName, 0, rowCounter);
		gridPane.add(labelHeaderPrice, 1, rowCounter);
		rowCounter++;
		
		for (int i = 0; i < transactions.getTransactionHistory().size(); i++)
		{
			// Create labels for name and price
			Label labelName = new Label(transactions.getTransactionHistory().get(i).getProductName());
			labelName.setFont(font);
			Label labelPrice = new Label(currencyFormatter.format(transactions.getTransactionHistory().get(i).getProductPrice()));
			labelPrice.setFont(font);

			// Add in items to gridPane
			gridPane.add(labelName, 0, rowCounter);
			gridPane.add(labelPrice, 1, rowCounter);

			rowCounter++;
		}
		
		Label labelHeaderTotal = new Label("Total: ");
		labelHeaderTotal.setFont(fontBold);
		Label labelTotal = new Label(currencyFormatter.format(transactions.getMoneySpent()));
		labelTotal.setFont(font);
		
		gridPane.add(labelHeaderTotal, 0, rowCounter);
		gridPane.add(labelTotal, 1, rowCounter);
		rowCounter++;

		Label labelHeaderRemaining = new Label("Remaining: ");
		labelHeaderRemaining.setFont(fontBold);
		Label labelRemaining = new Label(currencyFormatter.format(transactions.getMoneyRemaining()));
		labelRemaining.setFont(font);
		
		gridPane.add(labelHeaderRemaining, 0, rowCounter);
		gridPane.add(labelRemaining, 1, rowCounter);
		rowCounter++;

		return gridPane;
	}

	private void vendTest(){
		Stage stage = new Stage();
		GridPane gridPane = new GridPane();
		gridPane.setPadding(new Insets (10, 10, 10, 10));
		gridPane.setVgap(10);
		gridPane.setHgap(10);
		Scene scene = new Scene(gridPane, 400, 250);
		//Button vendButton1, vendButton2, vendButton3, vendButton4, vendButton5;
		
		Image colaIMG = new Image ("CocaCola.png");
		Image dietColaIMG = new Image ("DietCocaCola.jpg");
		Image pepperIMG = new Image ("DrPepper.jpg");
		Image rBeerIMG = new Image ("AWRootBeer.jpg");
		Image spriteIMG = new Image("Sprite.jpg");
		
		ImageView colaImageView = new ImageView (colaIMG);
		ImageView dietColaImageView = new ImageView (dietColaIMG);
		ImageView pepperImageView = new ImageView (pepperIMG);
		ImageView rBeerImageView = new ImageView (rBeerIMG);
		ImageView spriteImageView = new ImageView (spriteIMG);
		
		Text drink1 = new Text(machine1.getStockedProduct(20).getProductName());
		Text drink2 = new Text(machine1.getStockedProduct(21).getProductName());
		Text drink3 = new Text(machine1.getStockedProduct(22).getProductName());
		Text drink4 = new Text(machine1.getStockedProduct(23).getProductName());
		Text drink5 = new Text(machine1.getStockedProduct(24).getProductName());
		
		Button vendButton1 = new Button("Vend");
		vendButton1.setOnAction(e -> {
			vend.animateTest(colaImageView);
		});
		Button vendButton2 = new Button("Vend");
		vendButton2.setOnAction(e -> {
			vend.animateTest(dietColaImageView);
			
		});
		Button vendButton3 = new Button("Vend");
		vendButton3.setOnAction(e -> {
			vend.animateTest(pepperImageView);
			
		});
		Button vendButton4 = new Button("Vend");
		vendButton4.setOnAction(e -> {
			vend.animateTest(rBeerImageView);
			
		});
		Button vendButton5 = new Button("Vend");
		vendButton5.setOnAction(e -> {
			vend.animateTest(spriteImageView);
			
		});
		Button resetButton1 = new Button("Reset");
		resetButton1.setOnAction(e -> {
			vend.resetAnimationTest(colaImageView);
	
		});
		Button resetButton2 = new Button("Reset");
		resetButton2.setOnAction(e -> {
			vend.resetAnimationTest(dietColaImageView);
	
		});
		Button resetButton3 = new Button("Reset");
		resetButton3.setOnAction(e -> {
			vend.resetAnimationTest(pepperImageView);
	
		});
		Button resetButton4 = new Button("Reset");
		resetButton4.setOnAction(e -> {
			vend.resetAnimationTest(rBeerImageView);
	
		});
		Button resetButton5 = new Button("Reset");
		resetButton5.setOnAction(e -> {
			vend.resetAnimationTest(spriteImageView);
	
		});
		
		Rectangle vendBox = new Rectangle();
		vendBox.setWidth(340);
		vendBox.setHeight(60);
		
		gridPane.add(colaImageView, 0, 0);
		gridPane.add(dietColaImageView, 1, 0);
		gridPane.add(pepperImageView, 2, 0);
		gridPane.add(rBeerImageView, 3, 0);
		gridPane.add(spriteImageView, 4, 0);
		
		gridPane.add(drink1, 0, 1);
		gridPane.add(drink2, 1, 1);
		gridPane.add(drink3, 2, 1);
		gridPane.add(drink4, 3, 1);
		gridPane.add(drink5, 4, 1);
		
		gridPane.add(vendButton1, 0, 2);
		gridPane.add(vendButton2, 1, 2);
		gridPane.add(vendButton3, 2, 2);
		gridPane.add(vendButton4, 3, 2);
		gridPane.add(vendButton5, 4, 2);
		
		gridPane.add(resetButton1, 0, 3);
		gridPane.add(resetButton2, 1, 3);
		gridPane.add(resetButton3, 2, 3);
		gridPane.add(resetButton4, 3, 3);
		gridPane.add(resetButton5, 4, 3);
		
		gridPane.add(vendBox, 0, 4, 5, 1);
		
		updateScene(stage, scene);
	}
	
	class InventoryManagement implements EventHandler<ActionEvent>
	{
		@Override
		public void handle(ActionEvent event)
		{
			/* 
			 * Categories of product
			 */
			if (event.getSource() == drinksBTN)
			{
				displayItems("Drink");
			}
			if (event.getSource() == gumBTN)
			{
				displayItems("Gum");
			}
			if (event.getSource() == chipsBTN)
			{
				displayItems("Chips");
			}
			if (event.getSource() == candyBTN)
			{
				displayItems("Candy");
			}
			/* 
			 *
			 */
		}
	}
}