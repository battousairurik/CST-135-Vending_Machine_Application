package Vending_Machine;

import java.text.NumberFormat;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class DispenserGUI extends Application implements EventHandler<ActionEvent>{

	private Dispenser machine1 = new Dispenser();
	
	private Font font = new Font("Arial", 14);
	private Font fontBold = new Font("Arial Bold", 14);
	
	// To format $$ strings
	private NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();

	Button drinksBTN;
	
	public static void main(String[] args) {
        launch(args);
    }
	
	@Override
	public void start(Stage stage1) throws Exception {
		

		stage1.setTitle("Vending Machine Demo");
		stage1.setScene(new Scene(createMainScreen()));
		stage1.setWidth(350);
		stage1.setHeight(200);
        stage1.show();
	}
	public VBox createMainScreen(){
		VBox display = new VBox(10);
		
		Button selectionDisplay = new Button ("Selection by Category");
		selectionDisplay.setOnAction(e -> createSelectionGUI());
		
		Button fullDisplay = new Button ("Display all Inventory");
		
		display.getChildren().addAll(selectionDisplay, fullDisplay);
		display.setPadding(new Insets(15, 15, 15, 15));
		
		display.setAlignment(Pos.CENTER);
		
		return display;
	}
	
	public void createSelectionGUI(){
		Stage stage = new Stage();
		
		drinksBTN = new Button ("Drinks");
		Button candyBTN = new Button ("Candy");
		Button chipsBTN = new Button ("Chips");
		Button gumBTN = new Button ("Gum");
		
		Image drinksIMG = new Image("drinks.jpg");
		Image candyIMG = new Image("candy.jpg");
		Image chipsIMG = new Image("chips.png");
		Image gumIMG = new Image("gum.jpg");

		ImageView imageViewDrinks = new ImageView(drinksIMG);
		ImageView imageViewCandy = new ImageView(candyIMG);
		ImageView imageViewChips = new ImageView(chipsIMG);
		ImageView imageViewGum = new ImageView(gumIMG);
		
		ImageView pic = new ImageView();
		pic.setFitHeight(50);
		pic.setFitWidth(50);
		
		GridPane gridPane = new GridPane();
		gridPane.setPadding(new Insets (10, 10, 10, 10));
		gridPane.setVgap(10);
		gridPane.setHgap(10);
		
		gridPane.add(imageViewDrinks, 0, 0);
		gridPane.add(drinksBTN, 0, 1);
		GridPane.setHalignment(drinksBTN, HPos.CENTER);
		
		gridPane.add(imageViewCandy, 1, 0);
		gridPane.add(candyBTN, 1, 1);
		GridPane.setHalignment(candyBTN, HPos.CENTER);
		
		gridPane.add(imageViewChips, 0, 2);
		gridPane.add(chipsBTN, 0, 3);
		GridPane.setHalignment(chipsBTN, HPos.CENTER);
		
		gridPane.add(imageViewGum, 1, 2);
		gridPane.add(gumBTN, 1, 3);
		GridPane.setHalignment(gumBTN, HPos.CENTER);
		
		//Original manner of handling action events
		drinksBTN.setOnAction(this);
		
		//Compact method for introducing ActionEvents
		candyBTN.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            	displayItems("Candy");
            }
        });
        
		// Lambda expressions introduced in Java 8+
		chipsBTN.setOnAction(e -> displayItems("Chips"));
		gumBTN.setOnAction( e -> displayItems("Gum"));
		
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		stage.setTitle("Product display by type");
		stage.setScene(new Scene (gridPane));
		stage.show();
	}
	
	private void displayItems(String productType)
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		stage.setScene(new Scene(populateProductsGridPane(productType)));
		stage.show();
	}
	
	private GridPane populateProductsGridPane(String productType)
	{
		// Start with $20
		TransactionProcessing transactions = new TransactionProcessing(20.00);
		
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);

		// Will count up for each new item
		int rowCounter = 0;
		
		// gridPane headers
		Label labelHeaderSelect = new Label("Select");
		labelHeaderSelect.setFont(fontBold);
		Label labelHeaderName = new Label("Name");
		labelHeaderName.setFont(fontBold);
		Label labelHeaderLocation = new Label("Location");
		labelHeaderLocation.setFont(fontBold);
		Label labelHeaderPrice = new Label("Price");
		labelHeaderPrice.setFont(fontBold);
		Label labelHeaderQuantity = new Label("Quantity");
		labelHeaderQuantity.setFont(fontBold);
		
		gridPane.add(labelHeaderSelect, 0, rowCounter);
		gridPane.add(labelHeaderName, 1, rowCounter);
		gridPane.add(labelHeaderLocation, 2, rowCounter);
		gridPane.add(labelHeaderPrice, 3, rowCounter);
		gridPane.add(labelHeaderQuantity, 4, rowCounter);
		rowCounter++;
		
		// Item selection radio buttons
		ArrayList<RadioButton> buyRadioButtons = new ArrayList<>();
		final ToggleGroup toggleGroup = new ToggleGroup();
		
		// Check for product type and populate grid
		switch (productType)
		{
		case "Gum":
			for (int i = 0; i < machine1.getTotalNumberOfProducts(); i++)
			{
				if (machine1.getStockedProduct(i) instanceof Gum)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(machine1.getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(machine1.getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(machine1.getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + machine1.getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);

					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		case "Drink":
			for (int i = 0; i < machine1.getTotalNumberOfProducts(); i++)
			{
				if (machine1.getStockedProduct(i) instanceof Drink)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(machine1.getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(machine1.getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(machine1.getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + machine1.getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);

					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		case "Chips":
			for (int i = 0; i < machine1.getTotalNumberOfProducts(); i++)
			{
				if (machine1.getStockedProduct(i) instanceof Chips)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(machine1.getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(machine1.getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(machine1.getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + machine1.getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);

					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		case "Candy":
			for (int i = 0; i < machine1.getTotalNumberOfProducts(); i++)
			{
				if (machine1.getStockedProduct(i) instanceof Candy)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(machine1.getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(machine1.getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(machine1.getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + machine1.getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);

					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		}
		
		// Buy button
		Button buyBTN = new Button("Buy");
		gridPane.add(buyBTN, 0, rowCounter);
		buyBTN.setOnAction(e ->
		{
			for (int i = 0; i < buyRadioButtons.size(); i++)
			{
				// Check which radio button is selected
				if (buyRadioButtons.get(i).isSelected())
				{
					int selectedItem = Integer.parseInt(buyRadioButtons.get(i).getId());
					
					// Check if item is available
					if (machine1.getStockedProduct(selectedItem).getProductAmount() > 0)
					{
						machine1.getStockedProduct(selectedItem)
								.setProductAmount(machine1.getStockedProduct(selectedItem).getProductAmount() - 1);
						
						transactions.addTransaction(machine1.getStockedProduct(selectedItem));
					}
					
					// Only one radio button can be selected
					// No need to continue loop after this point
					break;
				}
			}
		});

		// Done button
		Button doneBTN = new Button("Done");
		gridPane.add(doneBTN, 4, rowCounter);
		doneBTN.setOnAction(e -> displayTransactions(transactions));
		
		rowCounter++;
		
		return gridPane;
	}
	
	private void displayTransactions(TransactionProcessing transactions)
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		stage.setScene(new Scene(populateTransactionsGridPane(transactions)));
		stage.show();
	}
	
	private GridPane populateTransactionsGridPane(TransactionProcessing transactions)
	{
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);

		// Will count up for each new item
		int rowCounter = 0;
		
		// gridPane headers
		Label labelHeaderName = new Label("Name");
		labelHeaderName.setFont(fontBold);
		Label labelHeaderPrice= new Label("Price");
		labelHeaderPrice.setFont(fontBold);
		
		gridPane.add(labelHeaderName, 0, rowCounter);
		gridPane.add(labelHeaderPrice, 1, rowCounter);
		rowCounter++;
		
		for (int i = 0; i < transactions.getTransactionHistory().size(); i++)
		{
			// Create labels for name and price
			Label labelName = new Label(transactions.getTransactionHistory().get(i).getProductName());
			labelName.setFont(font);
			Label labelPrice = new Label(currencyFormatter.format(transactions.getTransactionHistory().get(i).getProductPrice()));
			labelPrice.setFont(font);

			// Add in items to gridPane
			gridPane.add(labelName, 0, rowCounter);
			gridPane.add(labelPrice, 1, rowCounter);

			rowCounter++;
		}
		
		Label labelHeaderTotal = new Label("Total: ");
		labelHeaderTotal.setFont(fontBold);
		Label labelTotal = new Label(currencyFormatter.format(transactions.getMoneySpent()));
		labelTotal.setFont(font);
		
		gridPane.add(labelHeaderTotal, 0, rowCounter);
		gridPane.add(labelTotal, 1, rowCounter);
		rowCounter++;

		Label labelHeaderRemaining = new Label("Remaining: ");
		labelHeaderRemaining.setFont(fontBold);
		Label labelRemaining = new Label(currencyFormatter.format(transactions.getMoneyRemaining()));
		labelRemaining.setFont(font);
		
		gridPane.add(labelHeaderRemaining, 0, rowCounter);
		gridPane.add(labelRemaining, 1, rowCounter);
		rowCounter++;
		
		return gridPane;
	}
	@Override
	public void handle(ActionEvent event) {
		// TODO Auto-generated method stub
		if (event.getSource() == drinksBTN ){
			displayItems("Drink");
		}
	}
		
}
