package Vending_Machine;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class DispenserGUI extends Application{

	private Dispenser machine1 = new Dispenser();

	@Override
	public void start(Stage stage1) throws Exception {
		
		Button drinksBTN = new Button ("Drinks");
		Button candyBTN = new Button ("Candy");
		Button chipsBTN = new Button ("Chips");
		Button gumBTN = new Button ("Gum");
		
		Image drinksIMG = new Image ("file: drinks.jpg");
		Image candyIMG = new Image ("file: candy.jpg");
		Image chipsIMG = new Image ("file: chips.png");
		Image gumIMG = new Image ("file: gum.jpg");
		
		ImageView pic = new ImageView();
		pic.setFitHeight(50);
		pic.setFitWidth(50);
		
		GridPane gridPane = new GridPane();
		//gridPane.getChildren().add(pic.setImage(drinksIMG));
		gridPane.add(drinksBTN, 0, 1, 1, 1);
		//gridPane.getChildren().add(new ImageView(candyIMG));
		gridPane.add(candyBTN, 1, 1, 1, 1);
		//gridPane.getChildren().add(new ImageView(chipsIMG));
		gridPane.add(chipsBTN, 2, 1, 1, 1);
		//gridPane.getChildren().add(new ImageView(gumIMG));
		gridPane.add(gumBTN, 3, 1, 1, 1);
		
		drinksBTN.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Hello World!");
            }
        });
		candyBTN.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Hello World!");
            }
        });
		chipsBTN.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Hello World!");
            }
        });
		gumBTN.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Hello World!");
            }
        });
		
		stage1.setScene(new Scene(gridPane, 300, 250));
        stage1.show();
	}
	public static void main(String[] args) {
        launch(args);
    }
	
}
