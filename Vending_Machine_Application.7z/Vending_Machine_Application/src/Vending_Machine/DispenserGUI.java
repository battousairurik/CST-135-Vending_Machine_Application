package Vending_Machine;

import java.io.File;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class DispenserGUI extends Application
{
	private GlobalInventoryManagement inventory = new GlobalInventoryManagement();
	
	private animationHandling vend = new animationHandling();
	
	private Font font = new Font("Arial", 14);
	private Font fontBold = new Font("Arial Bold", 14);
	
	// To format $$ strings
	private NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();

	// To format $$ strings without the $ symbol
	private DecimalFormat decimalFormatter = new DecimalFormat("0.00");
	
	// This will determine which dispenser the end user is interacting with
	// Not used for manager tools
	private int activeDispenser = 0;
	
	// Class variables
	Button drinksBTN;
	Button candyBTN;
	Button chipsBTN;
	Button gumBTN;
	
	// Start with $20
	TransactionProcessing transactions = new TransactionProcessing(20.00);
	
	public static void main(String[] args) {
        launch(args);
    }
	
	@Override
	public void start(Stage stage) throws Exception {		
		stage.setTitle("Vending Machine Demo");
		stage.setWidth(350);
		stage.setHeight(250);
		
		Scene scene = new Scene(createMainScreen());
		updateScene(stage, scene);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public VBox createCustomerModeGUI(){
		VBox display = new VBox(10);
		
		ObservableList<String> listDispensers = FXCollections.observableArrayList();
		for (int i = 0; i < inventory.getAllDispensers().size(); i ++)
		{
			listDispensers.add(inventory.getDispenser(i).getDispenserName());	
		}
		ComboBox comboBoxDispensers = new ComboBox(listDispensers);
		comboBoxDispensers.getSelectionModel().select(activeDispenser);
		
		// Update name and quantity text fields when new item is selected
		comboBoxDispensers.setOnAction(e ->
		{
			activeDispenser = comboBoxDispensers.getSelectionModel().getSelectedIndex();
		});
		
		Button selectionDisplay = new Button ("Selection by Category");
		selectionDisplay.setOnAction(e -> createSelectionGUI());
		
		Button fullDisplay = new Button ("Display all Inventory");
		fullDisplay.setOnAction(e -> displayAllInventory());
		
		Button animationTest = new Button ("Test Animation");
		animationTest.setOnAction(e -> vendTest());
		
		display.getChildren().addAll(comboBoxDispensers, selectionDisplay, fullDisplay, animationTest);
		display.setPadding(new Insets(15, 15, 15, 15));
		
		display.setAlignment(Pos.CENTER);
		
		return display;
	}
	
	public VBox createMainScreen(){
		VBox display = new VBox(10);
		
		Button customerMode = new Button ("Customer Mode");
		customerMode.setOnAction(e -> customerMode());
		
		Button dispenserManager = new Button ("Dispenser Manager");
		dispenserManager.setOnAction(e -> dispenserManager());
		
		display.getChildren().addAll(customerMode, dispenserManager);
		display.setPadding(new Insets(15, 15, 15, 15));
		
		display.setAlignment(Pos.CENTER);
		
		return display;
	}
	
	private void manageDispenser(int currentDispenser)
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("Manage Dispenser");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		Scene scene = new Scene(populateManageDispenserGridPane(currentDispenser));
		updateScene(stage, scene);
	}
	
	private void customerMode()
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("Customer Mode");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		Scene scene = new Scene(createCustomerModeGUI());
		updateScene(stage, scene);
	}
	
	private void dispenserManager()
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("Dispenser Manager");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		Scene scene = new Scene(populateDispenserManagerGridPane());
		updateScene(stage, scene);
	}
	
	private void createSelectionGUI(){
		Stage stage = new Stage();
		
		drinksBTN = new Button ("Drinks");
		candyBTN = new Button ("Candy");
		chipsBTN = new Button ("Chips");
		gumBTN = new Button ("Gum");
		
		Image drinksIMG = new Image("drinks.jpg");
		Image candyIMG = new Image("candy.jpg");
		Image chipsIMG = new Image("chips.png");
		Image gumIMG = new Image("gum.jpg");

		ImageView imageViewDrinks = new ImageView(drinksIMG);
		ImageView imageViewCandy = new ImageView(candyIMG);
		ImageView imageViewChips = new ImageView(chipsIMG);
		ImageView imageViewGum = new ImageView(gumIMG);
		
		ImageView pic = new ImageView();
		pic.setFitHeight(50);
		pic.setFitWidth(50);
		
		GridPane gridPane = new GridPane();
		gridPane.setPadding(new Insets (10, 10, 10, 10));
		gridPane.setVgap(10);
		gridPane.setHgap(10);
		
		gridPane.add(imageViewDrinks, 0, 0);
		gridPane.add(drinksBTN, 0, 1);
		GridPane.setHalignment(drinksBTN, HPos.CENTER);
		
		gridPane.add(imageViewCandy, 1, 0);
		gridPane.add(candyBTN, 1, 1);
		GridPane.setHalignment(candyBTN, HPos.CENTER);
		
		gridPane.add(imageViewChips, 0, 2);
		gridPane.add(chipsBTN, 0, 3);
		GridPane.setHalignment(chipsBTN, HPos.CENTER);
		
		gridPane.add(imageViewGum, 1, 2);
		gridPane.add(gumBTN, 1, 3);
		GridPane.setHalignment(gumBTN, HPos.CENTER);
		
		//Original manner of handling action events
		drinksBTN.setOnAction(new InventoryManagement());
		candyBTN.setOnAction(new InventoryManagement());
		chipsBTN.setOnAction(new InventoryManagement());
		gumBTN.setOnAction(new InventoryManagement());
		
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		stage.setTitle("Product display by type");
		
		Scene scene = new Scene(gridPane);
		updateScene(stage, scene);
	}
	
	private void displayItems(String productType)
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		Scene scene = new Scene(populateProductsGridPane(productType, stage));
		updateScene(stage, scene);
	}
	
	private void displayAllInventory()
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("Inventory");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		Scene scene = new Scene(populateInventoryGridPane());
		updateScene(stage, scene);
	}
	
	private void displayRestockList(ArrayList<Product> products, int currentDispenser)
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("Restock List");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		Scene scene = new Scene(populateRestockGridPane(products, currentDispenser));
		updateScene(stage, scene);
	}
	
	private GridPane populateEmptyRestockGridPane(int currentDispenser)
	{
		String dispenserName = inventory.getAllDispensers().get(currentDispenser).getDispenserName();
		GridPane gridPane = new GridPane();
		gridPane.setPadding(new Insets(5, 5, 5, 5));
		gridPane.setHgap(5);
		gridPane.setVgap(5);
		Label message = new Label("No items need to be ordered\r\nfor " + dispenserName + ".");
		message.setTextAlignment(TextAlignment.CENTER);
		gridPane.add(message, 0, 0);
		return gridPane;
	}
	
	@SuppressWarnings("unused")
	private GridPane populateRestockGridPane(ArrayList<Product> products, int currentDispenser)
	{
		GridPane gridPane = new GridPane();
		gridPane.setPadding(new Insets(5, 5, 5, 5));
		gridPane.setHgap(15);
		gridPane.setVgap(5);
		
		if (products.size() == 0)
		{
			return populateEmptyRestockGridPane(currentDispenser);
		}
		
		for (int i = 0; i < products.size(); i++)
		{
			if (products.get(i).getProductDispenser() == inventory.getAllDispensers().get(currentDispenser)
					.getDispenserName())
			{
				break;
			}
			
			// If no matches found for current dispenser
			return populateEmptyRestockGridPane(currentDispenser);
		}
		
		// Update name and quantity text fields when new item is selected
		int rowCounter = 0;

		Label headerName = new Label("Name");
		headerName.setFont(fontBold);
		gridPane.add(headerName, 0, rowCounter);

		Label headerQuantity = new Label("Quantity");
		headerQuantity.setFont(fontBold);
		gridPane.add(headerQuantity, 1, rowCounter);

		Label headerDispenser = new Label("Dispenser");
		headerDispenser.setFont(fontBold);
		gridPane.add(headerDispenser, 2, rowCounter);
		
		Label headerOrder = new Label("Order");
		headerOrder.setFont(fontBold);
		gridPane.add(headerOrder, 3, rowCounter);
		
		Label headerCost = new Label("Cost");
		headerCost.setFont(fontBold);
		gridPane.add(headerCost, 4, rowCounter);

		rowCounter++;

		int totalQuantity = 0;
		int totalOrder = 0;
		double totalCost = 0;
		
		for (int i = 0; i < products.size(); i++)
		{
			if (products.get(i).getProductDispenser() == inventory.getAllDispensers().get(currentDispenser).getDispenserName())
			{
				Label labelProductName = new Label(products.get(i).getProductName());
				labelProductName.setFont(font);
				gridPane.add(labelProductName, 0, rowCounter);

				int productQuantity = products.get(i).getProductAmount();
				Label labelProductQuantity = new Label("" + products.get(i).getProductAmount());
				labelProductQuantity.setFont(font);
				gridPane.add(labelProductQuantity, 1, rowCounter);
				totalQuantity += productQuantity;
				
				Label labelProductDispenser = new Label("" + products.get(i).getProductDispenser());
				labelProductDispenser.setFont(font);
				gridPane.add(labelProductDispenser, 2, rowCounter);
				
				int order = 20 - products.get(i).getProductAmount();
				totalOrder += order;
				Label labelOrder = new Label("" + order);
				labelOrder.setFont(font);
				gridPane.add(labelOrder, 3, rowCounter);
				
				double itemPrice = products.get(i).getProductPrice();
				double cost = order * itemPrice;
				totalCost += cost;
				Label labelCost = new Label(currencyFormatter.format(cost));
				labelCost.setFont(font);
				gridPane.add(labelCost, 4, rowCounter);

				rowCounter++;
			}
		}
		
		Label labelTotals = new Label("Totals");
		labelTotals.setFont(fontBold);
		gridPane.add(labelTotals, 0, rowCounter);
		
		Label labelTotalQuantity = new Label("" + totalQuantity);
		labelTotalQuantity.setFont(font);
		gridPane.add(labelTotalQuantity, 1, rowCounter);
		
		Label labelTotalOrderRequest = new Label("" + totalOrder);
		labelTotalOrderRequest.setFont(font);
		gridPane.add(labelTotalOrderRequest, 3, rowCounter);
		
		Label labelTotalCost = new Label(currencyFormatter.format(totalCost));
		labelTotalCost.setFont(font);
		gridPane.add(labelTotalCost, 4, rowCounter);

		return gridPane;
	}
	
	private GridPane populateInventoryGridPane()
	{
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);
		
		// Will count up for each new item
		int rowCounter = 0;
		
		// gridPane headers
		Label labelHeaderName = new Label("Name");
		labelHeaderName.setFont(fontBold);
		Label labelHeaderLocation = new Label("Location");
		labelHeaderLocation.setFont(fontBold);
		Label labelHeaderPrice = new Label("Price");
		labelHeaderPrice.setFont(fontBold);
		Label labelHeaderQuantity = new Label("Quantity");
		labelHeaderQuantity.setFont(fontBold);
		
		gridPane.add(labelHeaderName, 0, rowCounter);
		gridPane.add(labelHeaderLocation, 1, rowCounter);
		gridPane.add(labelHeaderPrice, 2, rowCounter);
		gridPane.add(labelHeaderQuantity, 3, rowCounter);
		rowCounter++;
		
		for (int i = 0; i < inventory.getDispenser(activeDispenser).getTotalNumberOfProducts(); i++)
		{
			// Create labels for name, location, price and quantity
			Label labelName = new Label(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductName());
			labelName.setFont(font);
			Label labelLocation = new Label(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductLocation());
			labelLocation.setFont(font);
			Label labelPrice = new Label(currencyFormatter.format(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductPrice()));
			labelPrice.setFont(font);
			Label labelQuantity = new Label("" + inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductAmount());
			labelQuantity.setFont(font);

			// Add in items to gridPane
			gridPane.add(labelName, 0, rowCounter);
			gridPane.add(labelLocation, 1, rowCounter);
			gridPane.add(labelPrice, 2, rowCounter);
			gridPane.add(labelQuantity, 3, rowCounter);

			rowCounter++;
		}
		
		return gridPane;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private GridPane populateManageDispenserGridPane(int currentDispenser)
	{
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);
		
		ObservableList<String> listLocation = 
			    FXCollections.observableArrayList(
			    		"A1", "A2", "A3", "A4", "A5",
			    		"B1", "B2", "B3", "B4", "B5",
			    		"C1", "C2", "C3", "C4", "C5",
			    		"D1", "D2", "D3", "D4", "D5",
			    		"E1", "E2", "E3", "E4", "E5"
			    );
		ComboBox comboBoxLocation = new ComboBox(listLocation);
		comboBoxLocation.getSelectionModel().select(0);
		
		TextField textFieldName = new TextField(inventory.getDispenser(currentDispenser).getStockedProduct(0).getProductName());
		textFieldName.setMaxWidth(120);
		textFieldName.setPromptText("Name");
		
		TextField textFieldQuantity = new TextField("" + inventory.getDispenser(currentDispenser).getStockedProduct(0).getProductAmount());
		textFieldQuantity.setMaxWidth(60);
		textFieldQuantity.setPromptText("Quantity");
		
		TextField textFieldPrice = new TextField("" + decimalFormatter.format(inventory.getDispenser(currentDispenser).getStockedProduct(0).getProductPrice()));
		textFieldPrice.setMaxWidth(60);
		textFieldPrice.setPromptText("Price");
		
		Button buttonSave = new Button("Save");
		
		// Update name and quantity text fields when new item is selected
		comboBoxLocation.setOnAction(e ->
		{
			int selection = comboBoxLocation.getSelectionModel().getSelectedIndex();
			String itemName = inventory.getDispenser(currentDispenser).getStockedProduct(selection).getProductName();
			String itemQuantity = "" + inventory.getDispenser(currentDispenser).getStockedProduct(selection).getProductAmount();
			String itemPrice = "" + decimalFormatter.format(inventory.getDispenser(currentDispenser).getStockedProduct(selection).getProductPrice());
			textFieldName.setText(itemName);
			textFieldQuantity.setText(itemQuantity);
			textFieldPrice.setText(itemPrice);
		});

		// Check for integer in quantity
		// Return from method if it fails
		buttonSave.setOnAction(e ->
		{
			String inputQuantity = textFieldQuantity.getText();
			String inputPrice = textFieldPrice.getText();
			
			int selection = comboBoxLocation.getSelectionModel().getSelectedIndex();
			String name = "";
			int quantity = 0;
			double price = 0.0;
			
			name = textFieldName.getText();
			
			// Try-catch for quantity
			try
			{
				quantity = Integer.parseInt(inputQuantity);
				
				// Reject negative quantities
				if (quantity < 0)
				{
					ErrorMessage.display("Quantity cannot be below 0.", "Error");
					return;
				}
				// Reject absurdly high quantities
				else if (quantity > 50)
				{
					ErrorMessage.display("Quantity cannot exceed 50.", "Error");
					return;
				}
			}
			catch (Exception exception)
			{
				ErrorMessage.display("Not a valid integer.", "Error");
				return;
			}
			
			// Try-catch for price
			try
			{
				price = Double.parseDouble(inputPrice);
				
				// Reject negative prices
				if (price < 0)
				{
					ErrorMessage.display("Price cannot be below $0.00.", "Error");
					return;
				}
			}
			catch (Exception exception)
			{
				ErrorMessage.display("Not a valid number.", "Error");
				return;
			}
			
			// Save new product name
			inventory.getDispenser(currentDispenser).getStockedProduct(selection).setProductName(name);

			// Save new product quantity
			inventory.getDispenser(currentDispenser).getStockedProduct(selection).setProductAmount(quantity);
			
			// Save new product price
			inventory.getDispenser(currentDispenser).getStockedProduct(selection).setProductPrice(price);
		});
		
		gridPane.add(comboBoxLocation, 0, 0);
		gridPane.add(textFieldName, 1, 0);
		gridPane.add(textFieldQuantity, 2, 0);
		gridPane.add(textFieldPrice, 3, 0);
		gridPane.add(buttonSave, 3, 1);
		GridPane.setHalignment(buttonSave, HPos.RIGHT);
		
		return gridPane;
	}

	private String displayFileChooser()
	{
		Stage stage = new Stage();

		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Open .CSV File");
		fileChooser.getExtensionFilters().addAll(new ExtensionFilter(".CSV Spreadsheet", "*.csv"));
		File selectedFile = fileChooser.showOpenDialog(stage);

		if (selectedFile != null)
		{
			return selectedFile.toString();
		}

		return "";
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private GridPane populateDispenserManagerGridPane()
	{
		// Work in progress
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);

		ObservableList<String> listDispensers = FXCollections.observableArrayList();
		
		for (int i = 0; i < inventory.getAllDispensers().size(); i ++)
		{
			listDispensers.add(inventory.getDispenser(i).getDispenserName());	
		}
		
		ComboBox comboBoxDispensers = new ComboBox(listDispensers);
		comboBoxDispensers.getSelectionModel().select(0);
		
		Button buttonLoad = new Button("Load");
		Button buttonImport = new Button("Import .CSV");
		Button buttonRestock = new Button("Restock List");
		
		buttonImport.setOnAction(e ->
		{
			String filePath = displayFileChooser();
			
			// String value of "" indicates user canceled the file browser
			if (filePath != "")
			{
				try
				{
					inventory.addDispenser(filePath);
					int newestDispenser = inventory.getAllDispensers().size() - 1;
					listDispensers.add(inventory.getDispenser(newestDispenser).getDispenserName());	
				}
				catch(Exception ex)
				{
					ErrorMessage.display("Could not process .csv file.", "Error");
					return;
				}
			}
		});
		
		buttonLoad.setOnAction(e ->
		{
			int currentDispenser = comboBoxDispensers.getSelectionModel().getSelectedIndex();
			manageDispenser(currentDispenser);
		});
		
		buttonRestock.setOnAction(e ->
		{
			int currentDispenser = comboBoxDispensers.getSelectionModel().getSelectedIndex();
			Restock restock = new Restock(inventory.getAllDispensers());
			displayRestockList(restock.getLowStock(), currentDispenser);
		});
		
		gridPane.add(comboBoxDispensers, 0, 0);
		gridPane.add(buttonLoad, 1, 0);
		gridPane.add(buttonImport, 0, 2);
		gridPane.add(buttonRestock, 0, 4);
		
		return gridPane;
	}
	
	private void updateScene(Stage stage, Scene scene)
	{
		stage.setScene(scene);
		stage.show();
	}
	
	// Default the current selection to 0
	// Overloaded method so that other calls need not specify the current selection
	private GridPane populateProductsGridPane(String productType, Stage stage)
	{
		return populateProductsGridPane(productType, stage, 0); 
	}
	
	private GridPane populateProductsGridPane(String productType, Stage stage, int currentSelection)
	{
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);

		// Will count up for each new item
		int rowCounter = 0;
		
		// gridPane headers
		Label labelHeaderSelect = new Label("Select");
		labelHeaderSelect.setFont(fontBold);
		Label labelHeaderName = new Label("Name");
		labelHeaderName.setFont(fontBold);
		Label labelHeaderLocation = new Label("Location");
		labelHeaderLocation.setFont(fontBold);
		Label labelHeaderPrice = new Label("Price");
		labelHeaderPrice.setFont(fontBold);
		Label labelHeaderQuantity = new Label("Quantity");
		labelHeaderQuantity.setFont(fontBold);
		
		gridPane.add(labelHeaderSelect, 0, rowCounter);
		gridPane.add(labelHeaderName, 1, rowCounter);
		gridPane.add(labelHeaderLocation, 2, rowCounter);
		gridPane.add(labelHeaderPrice, 3, rowCounter);
		gridPane.add(labelHeaderQuantity, 4, rowCounter);
		rowCounter++;
		
		// Item selection radio buttons
		ArrayList<RadioButton> buyRadioButtons = new ArrayList<>();
		final ToggleGroup toggleGroup = new ToggleGroup();
		
		// Check for product type and populate grid
		switch (productType)
		{
		case "Gum":
			for (int i = 0; i < inventory.getDispenser(activeDispenser).getTotalNumberOfProducts(); i++)
			{
				if (inventory.getDispenser(activeDispenser).getStockedProduct(i) instanceof Gum)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);

					Rectangle placeHolder = new Rectangle();
					placeHolder.setWidth(20);
					placeHolder.setHeight(20);
					
					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					gridPane.add(placeHolder, 5, rowCounter);
					gridPane.add(new Text ("          "), 6, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		case "Drink":
			for (int i = 0; i < inventory.getDispenser(activeDispenser).getTotalNumberOfProducts(); i++)
			{
				if (inventory.getDispenser(activeDispenser).getStockedProduct(i) instanceof Drink)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);

					Rectangle placeHolder = new Rectangle();
					placeHolder.setWidth(20);
					placeHolder.setHeight(20);
					
					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					gridPane.add(placeHolder, 5, rowCounter);
					gridPane.add(new Text ("          "), 6, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		case "Chips":
			for (int i = 0; i < inventory.getDispenser(activeDispenser).getTotalNumberOfProducts(); i++)
			{
				if (inventory.getDispenser(activeDispenser).getStockedProduct(i) instanceof Chips)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);
					
					Rectangle placeHolder = new Rectangle();
					placeHolder.setWidth(20);
					placeHolder.setHeight(20);

					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					gridPane.add(placeHolder, 5, rowCounter);
					gridPane.add(new Text ("          "), 6, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		case "Candy":
			for (int i = 0; i < inventory.getDispenser(activeDispenser).getTotalNumberOfProducts(); i++)
			{
				if (inventory.getDispenser(activeDispenser).getStockedProduct(i) instanceof Candy)
				{
					// Create labels for name, location, price and quantity
					Label labelName = new Label(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductName());
					labelName.setFont(font);
					Label labelLocation = new Label(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductLocation());
					labelLocation.setFont(font);
					Label labelPrice = new Label(
							currencyFormatter.format(inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductPrice()));
					labelPrice.setFont(font);
					Label labelQuantity = new Label("" + inventory.getDispenser(activeDispenser).getStockedProduct(i).getProductAmount());
					labelQuantity.setFont(font);

					buyRadioButtons.add(new RadioButton());
					buyRadioButtons.get(rowCounter - 1).setId("" + i);
					buyRadioButtons.get(rowCounter - 1).setToggleGroup(toggleGroup);

					Rectangle placeHolder = new Rectangle();
					placeHolder.setWidth(20);
					placeHolder.setHeight(20);
					
					// Add in items to gridPane
					gridPane.add(buyRadioButtons.get(rowCounter - 1), 0, rowCounter);
					gridPane.add(labelName, 1, rowCounter);
					gridPane.add(labelLocation, 2, rowCounter);
					gridPane.add(labelPrice, 3, rowCounter);
					gridPane.add(labelQuantity, 4, rowCounter);
					gridPane.add(placeHolder, 5, rowCounter);
					gridPane.add(new Text ("          "), 6, rowCounter);
					GridPane.setHalignment(buyRadioButtons.get(rowCounter - 1), HPos.CENTER);

					rowCounter++;
				}
			}
			break;
		}
		
		// Because scene is updated after a purchase, the radio buttons are all unselected
		// This is to ensure the last purchased item is selected
		// The default currentSelection is 0 (the first item)
		for (int i = 0; i < buyRadioButtons.size(); i++)
		{
			if (i == currentSelection)
			{
				buyRadioButtons.get(i).setSelected(true);
				break;
			}
		}
		
		// Buy button
		Button buyBTN = new Button("Buy");
		gridPane.add(buyBTN, 0, rowCounter);
		buyBTN.setOnAction(e ->
		{
			for (int i = 0; i < buyRadioButtons.size(); i++)
			{
				// Check which radio button is selected
				if (buyRadioButtons.get(i).isSelected())
				{
					int selectedItem = Integer.parseInt(buyRadioButtons.get(i).getId());
					
					// Check if item is available
					if (inventory.getDispenser(activeDispenser).getStockedProduct(selectedItem).getProductAmount() > 0)
					{
						// If transaction is successful, reduce quantity by 1
						// addTransaction returns true for valid transaction, false if customer cannot afford
						if (transactions.addTransaction(inventory.getDispenser(activeDispenser).getStockedProduct(selectedItem)))
						{
							inventory.getDispenser(activeDispenser).getStockedProduct(selectedItem)
									.setProductAmount(inventory.getDispenser(activeDispenser).getStockedProduct(selectedItem).getProductAmount() - 1);
						}
					}
					
					// updateScene method to reflect live quantity counts
					// Variable "i" is passed in as the currently selected item
					updateScene(stage, new Scene(populateProductsGridPane(productType, stage, i)));
					
					// Only one radio button can be selected
					// No need to continue loop after this point
					break;
				}
			}
		});
		

		// Done button
		Button doneBTN = new Button("Done");
		gridPane.add(doneBTN, 4, rowCounter);
		doneBTN.setOnAction(e -> displayTransactions(transactions));
		gridPane.add(new Rectangle (40, 20), 6, rowCounter);
		
		rowCounter++;
		
		return gridPane;
	}
	
	private void displayTransactions(TransactionProcessing transactions)
	{
		// Create stage
		Stage stage = new Stage();

		// Window title
		stage.setTitle("");

		// Make stage a dialog window
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		Scene scene = new Scene(populateTransactionsGridPane(transactions));
		updateScene(stage, scene);
	}
	
	private GridPane populateTransactionsGridPane(TransactionProcessing transactions)
	{
		GridPane gridPane = new GridPane();
		gridPane.setHgap(5);
		gridPane.setVgap(5);

		// Will count up for each new item
		int rowCounter = 0;
		
		// gridPane headers
		Label labelHeaderName = new Label("Name");
		labelHeaderName.setFont(fontBold);
		Label labelHeaderPrice= new Label("Price");
		labelHeaderPrice.setFont(fontBold);
		
		gridPane.add(labelHeaderName, 0, rowCounter);
		gridPane.add(labelHeaderPrice, 1, rowCounter);
		rowCounter++;
		
		for (int i = 0; i < transactions.getTransactionHistory().size(); i++)
		{
			// Create labels for name and price
			Label labelName = new Label(transactions.getTransactionHistory().get(i).getProductName());
			labelName.setFont(font);
			Label labelPrice = new Label(currencyFormatter.format(transactions.getTransactionHistory().get(i).getProductPrice()));
			labelPrice.setFont(font);

			// Add in items to gridPane
			gridPane.add(labelName, 0, rowCounter);
			gridPane.add(labelPrice, 1, rowCounter);

			rowCounter++;
		}
		
		Label labelHeaderTotal = new Label("Total: ");
		labelHeaderTotal.setFont(fontBold);
		Label labelTotal = new Label(currencyFormatter.format(transactions.getMoneySpent()));
		labelTotal.setFont(font);
		
		gridPane.add(labelHeaderTotal, 0, rowCounter);
		gridPane.add(labelTotal, 1, rowCounter);
		rowCounter++;

		Label labelHeaderRemaining = new Label("Remaining: ");
		labelHeaderRemaining.setFont(fontBold);
		Label labelRemaining = new Label(currencyFormatter.format(transactions.getMoneyRemaining()));
		labelRemaining.setFont(font);
		
		gridPane.add(labelHeaderRemaining, 0, rowCounter);
		gridPane.add(labelRemaining, 1, rowCounter);
		rowCounter++;

		return gridPane;
	}

	private void vendTest(){
		Stage stage = new Stage();
		GridPane gridPane = new GridPane();
		gridPane.setPadding(new Insets (10, 10, 10, 10));
		gridPane.setVgap(10);
		gridPane.setHgap(10);
		Scene scene = new Scene(gridPane, 400, 250);
		//Button vendButton1, vendButton2, vendButton3, vendButton4, vendButton5;
		
		Image colaIMG = new Image ("CocaCola.png");
		Image dietColaIMG = new Image ("DietCocaCola.jpg");
		Image pepperIMG = new Image ("DrPepper.jpg");
		Image rBeerIMG = new Image ("AWRootBeer.jpg");
		Image spriteIMG = new Image("Sprite.jpg");
		
		ImageView colaImageView = new ImageView (colaIMG);
		ImageView dietColaImageView = new ImageView (dietColaIMG);
		ImageView pepperImageView = new ImageView (pepperIMG);
		ImageView rBeerImageView = new ImageView (rBeerIMG);
		ImageView spriteImageView = new ImageView (spriteIMG);
		
		Text drink1 = new Text(inventory.getDispenser(activeDispenser).getStockedProduct(20).getProductName());
		Text drink2 = new Text(inventory.getDispenser(activeDispenser).getStockedProduct(21).getProductName());
		Text drink3 = new Text(inventory.getDispenser(activeDispenser).getStockedProduct(22).getProductName());
		Text drink4 = new Text(inventory.getDispenser(activeDispenser).getStockedProduct(23).getProductName());
		Text drink5 = new Text(inventory.getDispenser(activeDispenser).getStockedProduct(24).getProductName());
		
		Button vendButton1 = new Button("Vend");
		vendButton1.setOnAction(e -> {
			vend.animateTest(colaImageView);
		});
		Button vendButton2 = new Button("Vend");
		vendButton2.setOnAction(e -> {
			vend.animateTest(dietColaImageView);
			
		});
		Button vendButton3 = new Button("Vend");
		vendButton3.setOnAction(e -> {
			vend.animateTest(pepperImageView);
			
		});
		Button vendButton4 = new Button("Vend");
		vendButton4.setOnAction(e -> {
			vend.animateTest(rBeerImageView);
			
		});
		Button vendButton5 = new Button("Vend");
		vendButton5.setOnAction(e -> {
			vend.animateTest(spriteImageView);
			
		});
		Button resetButton1 = new Button("Reset");
		resetButton1.setOnAction(e -> {
			vend.resetAnimationTest(colaImageView);
	
		});
		Button resetButton2 = new Button("Reset");
		resetButton2.setOnAction(e -> {
			vend.resetAnimationTest(dietColaImageView);
	
		});
		Button resetButton3 = new Button("Reset");
		resetButton3.setOnAction(e -> {
			vend.resetAnimationTest(pepperImageView);
	
		});
		Button resetButton4 = new Button("Reset");
		resetButton4.setOnAction(e -> {
			vend.resetAnimationTest(rBeerImageView);
	
		});
		Button resetButton5 = new Button("Reset");
		resetButton5.setOnAction(e -> {
			vend.resetAnimationTest(spriteImageView);
	
		});
		
		Rectangle vendBox = new Rectangle();
		vendBox.setWidth(340);
		vendBox.setHeight(60);
		
		gridPane.add(colaImageView, 0, 0);
		gridPane.add(dietColaImageView, 1, 0);
		gridPane.add(pepperImageView, 2, 0);
		gridPane.add(rBeerImageView, 3, 0);
		gridPane.add(spriteImageView, 4, 0);
		
		gridPane.add(drink1, 0, 1);
		gridPane.add(drink2, 1, 1);
		gridPane.add(drink3, 2, 1);
		gridPane.add(drink4, 3, 1);
		gridPane.add(drink5, 4, 1);
		
		gridPane.add(vendButton1, 0, 2);
		gridPane.add(vendButton2, 1, 2);
		gridPane.add(vendButton3, 2, 2);
		gridPane.add(vendButton4, 3, 2);
		gridPane.add(vendButton5, 4, 2);
		
		gridPane.add(resetButton1, 0, 3);
		gridPane.add(resetButton2, 1, 3);
		gridPane.add(resetButton3, 2, 3);
		gridPane.add(resetButton4, 3, 3);
		gridPane.add(resetButton5, 4, 3);
		
		gridPane.add(vendBox, 0, 4, 5, 1);
		
		updateScene(stage, scene);
	}
	
	class InventoryManagement implements EventHandler<ActionEvent>
	{
		@Override
		public void handle(ActionEvent event)
		{
			/* 
			 * Categories of product
			 */
			if (event.getSource() == drinksBTN)
			{
				displayItems("Drink");
			}
			if (event.getSource() == gumBTN)
			{
				displayItems("Gum");
			}
			if (event.getSource() == chipsBTN)
			{
				displayItems("Chips");
			}
			if (event.getSource() == candyBTN)
			{
				displayItems("Candy");
			}
			/* 
			 *
			 */
		}
	}
}