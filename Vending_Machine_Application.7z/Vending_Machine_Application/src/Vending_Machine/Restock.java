package Vending_Machine;

import java.util.ArrayList;

public class Restock {

	private ArrayList<Dispenser> machines;
	private ArrayList<Product> lowStock;
	
	public Restock()
	{
		machines = new ArrayList<>();
	}
	public Restock (ArrayList<Dispenser> Machines){
		machines = Machines;
		determineLowStock();
	}

	public void setDispenser (ArrayList<Dispenser> Machines){
		machines = Machines;
		determineLowStock();
	}

	private void determineLowStock()
	{
		lowStock = new ArrayList<>();
		for (int i = 0; i < machines.size(); i++)
		{
			for (int j = 0; j < machines.get(i).getTotalNumberOfProducts(); j++)
			{
				if (machines.get(i).getArrayListOfProducts().get(j).getProductAmount() <= 3)
				{
					lowStock.add(machines.get(i).getArrayListOfProducts().get(j));
				}
			}
		}
	}
	public ArrayList<Product> getLowStock () {
		return lowStock;
	}
}
