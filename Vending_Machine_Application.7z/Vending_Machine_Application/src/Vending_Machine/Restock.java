package Vending_Machine;

import java.util.ArrayList;

public class Restock {

	private Dispenser currentMachine;
	private ArrayList<Product> lowStock;
	
	public Restock () {}
	public Restock (Dispenser machine){
		currentMachine = machine;
	}
	public void setDispenser (Dispenser machine){
		currentMachine = machine;
	}
	public void determineLowStock (){
		ArrayList<Product> machineProducts = new ArrayList<Product>();
		machineProducts = currentMachine.getArrayListOfProducts();
		for (int i = 0; i < currentMachine.getTotalNumberOfProducts(); i++){
			if (machineProducts.get(i).getProductAmount() <= 3){
				lowStock.add(machineProducts.get(i));
			}
		}
	}
	public ArrayList<Product> getLowStock () {
		return lowStock;
	}
}
