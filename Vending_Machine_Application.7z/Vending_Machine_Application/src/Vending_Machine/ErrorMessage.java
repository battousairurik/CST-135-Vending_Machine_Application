package Vending_Machine;

import javafx.scene.control.Alert;

public class ErrorMessage
{
	public static void display(String message, String title)
	{
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle(title);
		alert.setHeaderText(message);
		alert.showAndWait();	
	}
}
