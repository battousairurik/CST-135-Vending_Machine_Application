package Vending_Machine;

import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.util.Duration;

public class animationHandling
{

	private int count = 0;
	
	public animationHandling()
	{
	}

	public void animateTest(Node node)
	{
		//if statement used to ensure that the animation can only be called once
		if (count == 0) {
		TranslateTransition vend = new TranslateTransition();
		vend.setNode(node);
		vend.setDuration(Duration.seconds(0.5));
		vend.setByY(160);
		vend.play();
		count++;
		}
	}

	public void resetAnimationTest(Node node)
	{
		if (count == 1) {
		TranslateTransition vend = new TranslateTransition();
		vend.setNode(node);
		vend.setDuration(Duration.seconds(0.001));
		vend.setByY(-160);
		vend.play();
		count--;
		}
	}
	
}
