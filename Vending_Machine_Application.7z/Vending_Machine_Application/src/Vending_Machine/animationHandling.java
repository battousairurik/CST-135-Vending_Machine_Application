package Vending_Machine;

import javafx.animation.SequentialTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class animationHandling
{

	private int count = 0;
	
	public animationHandling()
	{
	}

	public void animateTest(Node node)
	{
		//if statement used to ensure that the animation can only be called once
		if (count == 0) {
		TranslateTransition vend = new TranslateTransition();
		vend.setNode(node);
		vend.setDuration(Duration.seconds(0.5));
		vend.setByY(160);
		vend.play();
		count++;
		}
	}

	public void resetAnimationTest(Node node)
	{
		if (count == 1) {
		TranslateTransition vend = new TranslateTransition();
		vend.setNode(node);
		vend.setDuration(Duration.seconds(0.001));
		vend.setByY(-160);
		vend.play();
		count--;
		}
	}
	private int x = 0;
	
	public void animateSprite(ImageView sprite){
		TranslateTransition moveUp = new TranslateTransition();
		moveUp.setNode(sprite);
		moveUp.setDuration(Duration.seconds(1));
		moveUp.setToY(-50 * x++);
		
		TranslateTransition moveRight = new TranslateTransition();
		moveRight.setNode(sprite);
		moveRight.setDuration(Duration.seconds(1));
		moveRight.setToX(100);
		
		TranslateTransition moveDown = new TranslateTransition();
		moveDown.setNode(sprite);
		moveDown.setDuration(Duration.seconds(2));
		moveDown.setToY(300);
		
		SequentialTransition sequence = new SequentialTransition(moveUp, moveRight, moveDown);
		sequence.play();

	}
}
