package Vending_Machine;

import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.util.Duration;

public class animationHandling {

	public animationHandling(){	}
	
	public void animateTest(Node node){
		TranslateTransition vend = new TranslateTransition();
		vend.setNode(node);
		vend.setDuration(Duration.seconds(1));
		vend.setByX(20);
		vend.play();
		vend.setByY(-20);
		vend.play();
	}
	
}
