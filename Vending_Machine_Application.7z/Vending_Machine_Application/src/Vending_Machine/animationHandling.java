package Vending_Machine;

import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.util.Duration;

public class animationHandling
{

	public animationHandling()
	{
	}

	public void animateTest(Node node)
	{
		TranslateTransition vend = new TranslateTransition();
		vend.setNode(node);
		vend.setDuration(Duration.seconds(0.5));
		vend.setByY(160);
		vend.play();
	}

	public void resetAnimationTest(Node node)
	{
		TranslateTransition vend = new TranslateTransition();
		vend.setNode(node);
		vend.setDuration(Duration.seconds(0.001));
		vend.setByY(-160);
		vend.play();
	}
}
