package Vending_Machine;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class ProcessCustomerQueue {

	private File currentFile;
	private ArrayList<CustomerPurchases> customers = new ArrayList<CustomerPurchases> ();
	
	public ProcessCustomerQueue (){
		setDefaultFile();
		readFile();
	}
	public ProcessCustomerQueue (String filePath){
		setFile(filePath);
		readFile();
	}
	public void setFile (String filePath){
		currentFile = new File (filePath);
	}
	private void setDefaultFile () {
		currentFile = new File ("src\\CustomerList.csv");
	}
	public ArrayList<CustomerPurchases> getCustomerList (){
		return customers;
	}
	
	private void readFile () {
		String currentCustomer;
		
		try {
			Scanner inputStream = new Scanner (currentFile);
			
			while (inputStream.hasNext()){
				String data = inputStream.nextLine();
				String [] values = data.split(",");
				
				currentCustomer = values[0];
				
				if (currentCustomer.equals("END"))
					break;
				
				customers.add(handleCustomerTransaction(values));
			}
			inputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private CustomerPurchases handleCustomerTransaction (String [] values){
		CustomerPurchases customer = new CustomerPurchases();
		customer.setCustomerName(values[0]);
		for (int i = 1; i < values.length; i++){
			customer.addTransaction(values[i]);
			if (values[i].equals("Lay's")){
				i++;
				//Code to determine Lay's Chip Flavor
			}
		}
		return customer;
	}
	class CustomerPurchases {
		
		private String customerName;
		//Need to edit this to store an array of products to be purchased from the machine
		private ArrayList<String> purchases;
		
		public CustomerPurchases (){
			customerName = "";
			purchases = new ArrayList<String>();
		}
		
		public void setCustomerName (String name){
			customerName = name;
		}
		public String getCustomerName (){
			return customerName;
		}
		public void addTransaction (String purchase){
			purchases.add(purchase);
		}
		public ArrayList<String> getPurchases (){
			return purchases;
		}
	}
}

