package Vending_Machine;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
//Reads a list of customers in from a CSV file and stores all of the purchase data in object form
public class ProcessCustomerQueue {

	//Store Current File of customer purchases written in CSV format
	private File currentFile; 
	//Store an an ArrayList of all customers and their purchases
	private ArrayList<CustomerPurchases> customers = new ArrayList<CustomerPurchases> ();
	//Constructor utilizing default provided customer sample
	public ProcessCustomerQueue (){
		setDefaultFile();
		readFile();
	}
	//Constructor utilizing custom file the user provides
	public ProcessCustomerQueue (String filePath){
		setFile(filePath);
		readFile();
	}
	public void setFile (String filePath){
		currentFile = new File (filePath);
	}
	private void setDefaultFile () {
		currentFile = new File ("src\\CustomerList.csv");
	}
	//Method to return ArrayList
	public ArrayList<CustomerPurchases> getCustomerList (){
		return customers;
	}
	//Read data from the file into the program
	private void readFile () {
		//Placeholder to determine when the end the reading
		String currentCustomer = null;
		
		try {
			Scanner inputStream = new Scanner (currentFile);
			
			while (inputStream.hasNext()){
				//Read a single customer worth of data into the program
				String data = inputStream.nextLine();
				//Split the line into the customer name and intended purchases
				String [] values = data.split(",");
				//Customer name always comes first
				currentCustomer = values[0];
				//When the customer name is END the file has reached the end point and no longer needs processing
				if (currentCustomer.equals("END"))
					break;
				//Because of the if statement this step is skipped before the program can return a null object
				customers.add(handleCustomerTransaction(values));
			}
			//Always close your scanner
			inputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	private CustomerPurchases handleCustomerTransaction (String [] values){
		//Create customer purchases objects to store a single purchase list from a single customer
		CustomerPurchases customer = new CustomerPurchases();
		customer.setCustomerName(values[0]);
		for (int i = 1; i < values.length; i++){
			customer.addTransaction(values[i]);
			//Method to store chip flavor to prevent inaccurate purchases
			if (values[i].equals("Lay's")){
				i++;
				customer.setChipFlavor(values[i]);
			}
		}
		return customer;
	}
	//Personal Class for the ProcessCustomerClass to utilize in creating objects to store purchase data per customer
	class CustomerPurchases {
		
		private String customerName;
		private ArrayList<String> purchases;
		private String chipFlavor;
		
		public CustomerPurchases (){
			customerName = null;
			purchases = new ArrayList<String>();
			chipFlavor = null;
		}
		
		public void setCustomerName (String name){
			customerName = name;
		}
		public String getCustomerName (){
			return customerName;
		}
		public void addTransaction (String purchase){
			purchases.add(purchase);
		}
		public ArrayList<String> getPurchases (){
			return purchases;
		}
		public void setChipFlavor (String flavor){
			chipFlavor = flavor;
		}
		public String getChipFlavor () {
			return chipFlavor;
		}
	}
}

