package Vending_Machine;

import java.util.ArrayList;

public class Main
{

	private static void milestone2()
	{
		// Test the displayProducts method
		Dispenser dispenser = new Dispenser();
		dispenser.displayProducts();
	}
	private static void milestone3()
	{
		// Test the implementation of Comparable
		Chips chips1 = new Chips("Doritos", 2.00, 10, 10, "C1", "Frito-Lay", "Nacho Cheese");
		Chips chips2 = new Chips("Fritos", 2.00, 11, 8, "C2", "Frito-Lay", "Original");
		// chips1 is less than chips2, because "Doritos" comes before "Fritos" alphabetically
		System.out.println("chips1 compared to chips2: " + chips1.compareTo(chips2));
	}
	
	private static void displayGUI(String[] args)
	{
		DispenserGUI.main(args);
	}
	
	private static void inventoryTest()
	{
		GlobalInventoryManagement inventory = new GlobalInventoryManagement();
		ArrayList<Product> productList = inventory.getDispenser(0).getArrayListOfProducts();
		
		System.out.println("Sorting all items alphabetically:\r\n");
		inventory.sortItemsByName(0);
		for (int i = 0; i < productList.size(); i++)
		{
			System.out.println(productList.get(i).getProductName());
		}
		
		System.out.println("\r\nSearching for item with search terms:  \"Lay\"\r\n");
		
		String result = inventory.searchByProductName(inventory.getAllDispensers(), "Lay", 0, "");
		System.out.println(result);
	}
	
	public static void main(String[] args)
	{	
		//milestone2();
		//milestone3();
		//displayGUI(args);
		inventoryTest();
	}
}
