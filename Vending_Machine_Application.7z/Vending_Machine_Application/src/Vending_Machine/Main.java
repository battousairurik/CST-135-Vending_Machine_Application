package Vending_Machine;

public class Main
{

	public static void main(String[] args)
	{
		Dispenser dispenser = new Dispenser();
		
		//dispenser.displayProducts();
		dispenser.stockedProducts[0]
	}

}
