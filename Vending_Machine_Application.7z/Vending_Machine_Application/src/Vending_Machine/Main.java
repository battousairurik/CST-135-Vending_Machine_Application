package Vending_Machine;

public class Main
{

	public static void main(String[] args)
	{
		// Test the displayProducts method
		Dispenser dispenser = new Dispenser();
		dispenser.displayProducts();
		
		// Test the implementation of Comparable
		Chips chips1 = new Chips("Doritos", 	2.00, 10, 10, "C1", "Frito-Lay", "Nacho Cheese");
		Chips chips2 = new Chips("Fritos", 	2.00, 11, 8, "C2", "Frito-Lay", "Original");
		
		// chips1 is less than chips2, because "Doritos" comes before "Fritos" alphabetically
		System.out.println("chips1 compared to chips2: " + chips1.compareTo(chips2));
	}

}
