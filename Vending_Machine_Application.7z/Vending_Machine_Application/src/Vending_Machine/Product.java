package Vending_Machine;

public abstract class Product {

	private String productName;
	private Double productPrice;
	
	private int productID;
	private int productAmount;
	private String productLocation;
	private String productDispenser;
	private Boolean isStocked;
	
	// Default empty Constructor
	public Product(){
		productDispenser = "";
	}
	// Constructor for manual input
	public Product (String name, Double price, int ID, int amount, String location){
		setProductName(name);
		setProductPrice(price);
		setProductID(ID);
		setProductAmount(amount);
		setProductLocation(location);
		if (amount > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
	}
	
	// No need for copy constructor as this is an abstract class
	
	public void setProductName (String name){
		productName = name;
	}
	public String getProductName (){
		return productName;
	}
	public void setProductPrice (Double price){
		productPrice = price;
	}
	public Double getProductPrice (){
		return productPrice;
	}
	public void setProductID(int ID){
		productID = ID;
	}
	public int getProductID (){
		return productID;
	}
	public void setProductAmount (int amount){
		productAmount = amount;
	}
	public void setProductAmountMinusOne (){
		if (productAmount > 0)
			productAmount--;
	}
	public int getProductAmount (){
		return productAmount;
	}
	public void setProductLocation (String location){
		productLocation = location;
	}
	public String getProductLocation (){
		return productLocation;
	}
	public void setProductDispenser (String dispenser){
		productDispenser = dispenser;
	}
	public String getProductDispenser (){
		return productDispenser;
	}
	public void setIsStocked(boolean value){
		isStocked = value;
	}
	public boolean getIsStocked(){
		if (getProductAmount() > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
		
		return isStocked;
	}
	// toString method to list all product information
	@Override
	public String toString(){
		return "Product: " + getProductName()
		+ "\nPrice: " + getProductPrice()
		+ "\nID: " + getProductID()
		+ "\nAmount: " + getProductAmount()
		+ "\nLocation: " + getProductLocation()
		+ "\nStocked: " + getIsStocked();
	}
	
}
