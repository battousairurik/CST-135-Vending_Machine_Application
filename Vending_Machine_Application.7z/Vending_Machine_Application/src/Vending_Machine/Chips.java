package Vending_Machine;

public class Chips extends Snack{

	private String chipFlavor;
	
	//Default empty constructor
	public Chips()
	{
		setProductName("");
		setProductPrice(0.0);
		setProductID(-1);
		setProductAmount(0);
		setProductLocation("");
		setSnackBrand("");
		setChipFlavor("");
		setIsStocked(false);
	}
	// Constructor for manual input
	public Chips (String name, Double price, int ID, int amount, String location, String brand, String flavor){
		setProductName(name);
		setProductPrice(price);
		setProductID(ID);
		setProductAmount(amount);
		setProductLocation(location);
		setSnackBrand(brand);
		setChipFlavor(flavor);
		if (amount > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
	}
	
	// Copy constructor
	public Chips (Chips someChips){
		setProductName(someChips.getProductName());
		setProductPrice(someChips.getProductPrice());
		setProductID(someChips.getProductID());
		setProductAmount(someChips.getProductAmount());
		setProductLocation(someChips.getProductLocation());
		setSnackBrand(someChips.getSnackBrand());
		setChipFlavor(someChips.getChipFlavor());
		setIsStocked(someChips.getIsStocked());
	}
	
	public void setChipFlavor (String flavor){
		chipFlavor = flavor;
	}
	public String getChipFlavor (){
		return chipFlavor;
	}
	// toString method to list all product information
	@Override
	public String toString(){
		return "Product: " + getProductName()
		+ "\nPrice: " + getProductPrice()
		+ "\nID: " + getProductID()
		+ "\nAmount: " + getProductAmount()
		+ "\nLocation: " + getProductLocation()
		+ "\nBrand: " + getSnackBrand()
		+ "\nFlavor: " + getChipFlavor()
		+ "\nStocked: " + getIsStocked();
	}
}
