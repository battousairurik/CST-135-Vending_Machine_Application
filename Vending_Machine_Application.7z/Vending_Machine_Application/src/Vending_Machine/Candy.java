package Vending_Machine;

public class Candy extends Snack{

	private boolean isChocolate;
	
	public Candy () {};
	public Candy (String name, Double price, int ID, int amount, String location, String brand, boolean choc){
		setProductName(name);
		setProductPrice(price);
		setProductID(ID);
		setProductAmount(amount);
		setProductLocation(location);
		setSnackBrand(brand);
		setIsChocolate(choc);
		if (amount > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
	}
	public Candy (Candy someCandy){
		
	}
	
	public void setIsChocolate (boolean value){
		isChocolate = value;
	}
	public boolean getIsChocolate (){
		return isChocolate;
	}
	public String toString (){
		return "Product: " + getProductName()
			+ "\nPrice: " + getProductPrice()
			+ "\nID: " + getProductID()
			+ "\nAmount: " + getProductAmount()
			+ "\nLocation: " + getProductLocation()
			+ "\nBrand: " + getSnackBrand()
			+ "\nChocolate: " + getIsChocolate()
			+ "\nStocked: " + getIsStocked();
	}
}
