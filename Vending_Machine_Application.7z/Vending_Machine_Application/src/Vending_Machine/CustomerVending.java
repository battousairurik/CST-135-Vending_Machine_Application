package Vending_Machine;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Random;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;
//Need to create the reference then call the create customer line method in main GUI
public class CustomerVending {

	//Initialize reference
	private ProcessCustomerQueue queue1;
	private animationHandling animations;
	private ImageView personIV;
	private ImageView personIV2;
	private ImageView personIV3;
	private ImageView personIV4;
	private ImageView personIV5;
	private Dispenser currentDispenser;
	
	// To format $$ strings
	private NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
	
	public CustomerVending () {
		//create default customer queue
		queue1 = new ProcessCustomerQueue();
		animations = new animationHandling();
	}
	public CustomerVending(Dispenser CurrentDispenser)
	{
		queue1 = new ProcessCustomerQueue();
		animations = new animationHandling();
		currentDispenser = CurrentDispenser;
	}
	//utilize to plug in a scene in the main GUI
	public void createCustomerLine (){
		Stage stage = new Stage ();
		stage.setTitle("Customer Wait Line");
		stage.setWidth(300);
		stage.setHeight(400);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		GridPane display = new GridPane ();
		display.setPadding(new Insets (15, 15, 15,15));
		display.setHgap(15);
		
		Image machine = new Image ("VendingMachine.png");
		Image person = new Image ("Person.png");
		
		ImageView machineImageView = new ImageView (machine);
		personIV = new ImageView (person);
		personIV2 = new ImageView (person);
		personIV3 = new ImageView (person);
		personIV4 = new ImageView (person);
		personIV5 = new ImageView (person);
		
		Button proceed = new Button ("Next Customer");
		
		Text inventoryMessage = new Text("");
		inventoryMessage.setTextAlignment(TextAlignment.CENTER);

		proceed.setOnAction(e ->
		{
			if (choice < 6)
			{
				animations.animateSprite(selection());
				double x = stage.getX();
				double y = stage.getY();
				double width = stage.getWidth();
				purchaseHandling(x, y, width);
			}
			if (choice > 5)
			{
				inventoryMessage.setText("All customers\r\nhave been\r\nserved.");
				proceed.setDisable(true);
			}
		});
		
		display.add(machineImageView, 1, 0);
		display.add(proceed, 0, 0);
		display.add(inventoryMessage, 0, 1);
		display.add(personIV, 1, 1);
		display.add(personIV2, 1, 2);
		display.add(personIV3, 1, 3);
		display.add(personIV4, 1, 4);
		display.add(personIV5, 1, 5);

		Scene scene = new Scene (display);
		stage.setScene(scene);
		stage.show();
	}
	private int choice = 1;
	private ImageView selection() {
		if (choice == 1) {
			choice++;
			return personIV;
		}
		else if (choice == 2){
			choice++;
			return personIV2;
		}
		else if (choice == 3){
			choice++;
			return personIV3;
		}
		else if (choice == 4){
			choice++;
			return personIV4;
		}
		else if (choice == 5){
			choice++;
			return personIV5;
		}
		else return personIV;
	}
	private int customerIndex = 0;
	private void purchaseHandling (double x, double y, double width){	
		//Pop open a new Stage which displays the customer name and purchase list then vend from the machine if possible
		Stage stage = new Stage();
		//stage.setWidth(220);
		//stage.setHeight(240);
		stage.setX(x + width);
		stage.setY(y);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setResizable(false);
		
		VBox display = new VBox(10);
		display.setPadding(new Insets(5, 0, 0, 5));
		
		ProcessCustomerQueue.CustomerPurchases currentCustomer = queue1.getCustomerList().get(customerIndex);
		
		stage.setTitle(currentCustomer.getCustomerName() + "'s Purchase Log");
		
		String purchaseLog = "";
		purchaseLog += "Customer:  " + currentCustomer.getCustomerName() + "\r\n";
		
		Text purchaseText = new Text();
		
		purchaseLog = vendFromMachine(purchaseLog, currentCustomer, currentCustomer.getPurchases());
		
		purchaseText.setText(purchaseLog);
		display.getChildren().add(purchaseText);
		
		Scene scene = new Scene(display);
		stage.setScene(scene);
		stage.show();
		
		customerIndex++;
	}
	private String vendFromMachine(String purchaseLog, ProcessCustomerQueue.CustomerPurchases currentCustomer, ArrayList<String> purchases){
		//Retrieve customer order and then vend from the machine based on matching product name
		for (int i = 0; i < purchases.size(); i++)
		{
			String currentPurchase = currentCustomer.getPurchases().get(i);
			purchaseLog += "Item:  " + currentCustomer.getPurchases().get(i) + "\r\n";
			
			boolean isStocked;
			
			try
			{
				isStocked = currentDispenser.getStockedProduct(currentPurchase).getIsStocked();
			}
			catch(Exception ex)
			{
				isStocked = false;
			}

			if (isStocked)
			{
				purchaseLog += "In stock.  Purchased for " + currencyFormatter
						.format(currentDispenser.getStockedProduct(currentPurchase).getProductPrice()) + ".";

				currentDispenser.getStockedProduct(currentPurchase).setProductAmountMinusOne();
			}
			else
			{
				purchaseLog += "Out of stock.  Making new purchase.\r\n";
				purchaseLog = makeRandomPurchase(purchaseLog, 1);
			}
			
		}
		
		return purchaseLog;
	}
	
	private String makeRandomPurchase(String purchaseLog, int attempts)
	{
		Random random = new Random();
		int randomIndex = random.nextInt(currentDispenser.getTotalNumberOfProducts());
		
		purchaseLog += "Item:  " + currentDispenser.getStockedProduct(randomIndex).getProductName() + "\r\n";
		
		if (currentDispenser.getStockedProduct(randomIndex).getIsStocked())
		{
			purchaseLog += "In stock.  Purchased for "
					+ currencyFormatter.format(currentDispenser.getStockedProduct(randomIndex).getProductPrice()) + ".";
			
			currentDispenser.getStockedProduct(randomIndex).setProductAmountMinusOne();
			
			return purchaseLog;
		}
		else
		{
			purchaseLog += "Out of stock.  ";
			if (attempts < 4)
			{
				purchaseLog += "Making new purchase.\r\n";
				attempts++;
				purchaseLog = makeRandomPurchase(purchaseLog, attempts);
			}
			else
			{
				purchaseLog += "After five attempts, the\r\ncustomer gives up!";
			}
		}
		
		return purchaseLog;
	}
	
	public Dispenser getUpdatedDispenser()
	{
		return currentDispenser;
	}
}
