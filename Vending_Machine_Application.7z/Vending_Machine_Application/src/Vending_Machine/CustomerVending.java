package Vending_Machine;

import javafx.scene.layout.VBox;
//Need to create the reference then call the create customer line method in main GUI
public class CustomerVending {

	//Initialize reference
	private ProcessCustomerQueue queue1;
	
	public CustomerVending () {
		//create default customer queue
		queue1 = new ProcessCustomerQueue();
		
	}
	//utilize to plug in a scene in the main GUI
	public VBox createCustomerLine (){
		VBox scene = new VBox ();
		
		//Add code to run the rest of the customer line animations and handling
		
		return scene;
	}
}
