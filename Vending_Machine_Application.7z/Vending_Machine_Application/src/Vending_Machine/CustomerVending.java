package Vending_Machine;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
//Need to create the reference then call the create customer line method in main GUI
public class CustomerVending {

	//Initialize reference
	private ProcessCustomerQueue queue1;
	private animationHandling animations;
	private ImageView personIV;
	private ImageView personIV2;
	private ImageView personIV3;
	private ImageView personIV4;
	private ImageView personIV5;
	
	public CustomerVending () {
		//create default customer queue
		queue1 = new ProcessCustomerQueue();
		animations = new animationHandling();
	}
	//utilize to plug in a scene in the main GUI
	public void createCustomerLine (){
		Stage stage = new Stage ();
		stage.setTitle("Customer Wait Line");
		stage.setWidth(300);
		stage.setHeight(400);
		
		GridPane display = new GridPane ();
		display.setPadding(new Insets (15, 15, 15,15));
		
		Image machine = new Image ("VendingMachine.jpg");
		Image person = new Image ("Person.png");
		
		ImageView machineImageView = new ImageView (machine);
		personIV = new ImageView (person);
		personIV2 = new ImageView (person);
		personIV3 = new ImageView (person);
		personIV4 = new ImageView (person);
		personIV5 = new ImageView (person);
		
		Button proceed = new Button ("Next Customer");
		proceed.setOnAction(e -> {
			animations.animateSprite(selection());
			purchaseHandling();
		});
		
		display.add(machineImageView, 1, 0);
		display.add(proceed, 0, 0);
		display.add(personIV, 1, 1);
		display.add(personIV2, 1, 2);
		display.add(personIV3, 1, 3);
		display.add(personIV4, 1, 4);
		display.add(personIV5, 1, 5);
		
		Scene scene = new Scene (display);
		stage.setScene(scene);
		stage.show();
	}
	private int choice = 1;
	private ImageView selection() {
		if (choice == 1) {
			choice++;
			return personIV;
		}
		else if (choice == 2){
			choice++;
			return personIV2;
		}
		else if (choice == 3){
			choice++;
			return personIV3;
		}
		else if (choice == 4){
			choice++;
			return personIV4;
		}
		else if (choice == 5){
			choice++;
			return personIV5;
		}
		else return personIV;
	}
	private void purchaseHandling (){
		//Pop open a new Stage which displays the customer name and purchase list then vend from the machine if possible
	}
}
