package Vending_Machine;

public class Gum extends Snack{

	private boolean isSugarFree;
	
	public Gum () {};
	public Gum (String name, Double price, int ID, int amount, String location, String brand, boolean sugar){
		setProductName(name);
		setProductPrice(price);
		setProductID(ID);
		setProductAmount(amount);
		setProductLocation(location);
		setSnackBrand(brand);
		setIsSugarFree(sugar);
		if (amount > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
	}
	
	public void setIsSugarFree (boolean value){
		isSugarFree = value;
	}
	public boolean getIsSugarFree (){
		return isSugarFree;
	}
	public String toString(){
		return "Product: " + getProductName()
		+ "\nPrice: " + getProductPrice()
		+ "\nID: " + getProductID()
		+ "\nAmount: " + getProductAmount()
		+ "\nLocation: " + getProductLocation()
		+ "\nBrand: " + getSnackBrand()
		+ "\nSugarFree: " + getIsSugarFree()
		+ "\nStocked: " + getIsStocked();
	}
}
