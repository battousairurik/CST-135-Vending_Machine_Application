package Vending_Machine;

public class Gum extends Snack{

	private boolean isSugarFree;
	
	public Gum () {};
	public Gum (String name, Double price, int ID, int amount, String location, String brand, boolean sugar){
		setProductName(name);
		setProductPrice(price);
		setProductID(ID);
		setProductAmount(amount);
		setProductLocation(location);
		setSnackBrand(brand);
		setIsSugarFree(sugar);
		if (amount > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
	}
	
	// Copy constructor
	public Gum (Gum someGum){
		setProductName(someGum.getProductName());
		setProductPrice(someGum.getProductPrice());
		setProductID(someGum.getProductID());
		setProductAmount(someGum.getProductAmount());
		setProductLocation(someGum.getProductLocation());
		setSnackBrand(someGum.getSnackBrand());
		setIsSugarFree(someGum.getIsSugarFree());
		setIsStocked(someGum.getIsStocked());
	}
	
	public void setIsSugarFree (boolean value){
		isSugarFree = value;
	}
	public boolean getIsSugarFree (){
		return isSugarFree;
	}
	@Override
	public String toString(){
		return "Product: " + getProductName()
		+ "\nPrice: " + getProductPrice()
		+ "\nID: " + getProductID()
		+ "\nAmount: " + getProductAmount()
		+ "\nLocation: " + getProductLocation()
		+ "\nBrand: " + getSnackBrand()
		+ "\nSugarFree: " + getIsSugarFree()
		+ "\nStocked: " + getIsStocked();
	}
}
