package Vending_Machine;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class GlobalInventoryManagement {

	private File currentFile;
	private ArrayList<Product> products;
	
	//Default Constructor to set existing File
	public GlobalInventoryManagement(){
		setDefaultFile();
	}
	//Constructor to set any File
	public GlobalInventoryManagement(File file){
		setFile(file);
	}
	//Method to set default File
	private void setDefaultFile (){
		currentFile = new File ("machine1.csv");
	}
	//Method to set provided File
	public void setFile(File file){
		currentFile = file;
	}
	//Method to read contents of the File
	public void readFile (){
		
		try {
			Scanner inputStream = new Scanner (currentFile);
			
			while (inputStream.hasNext()){
				String data = inputStream.nextLine();
				String [] values = data.split(",");
				products.add(createEntry(values));
				
			}
			inputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//Create the ArrayList
	private Product createEntry (String [] product){
		String subClass = product[0];
		Product sample;
		switch (subClass) {
			default: 
			case "Candy": {
				sample = new Candy(product[1], Double.parseDouble(product[2]), 
						Integer.parseInt(product[3]), Integer.parseInt(product[4]), 
						product[5], product[6], Boolean.parseBoolean(product[7]));
			}
			case "Chips": {
				sample = new Chips(product[1], Double.parseDouble(product[2]), 
						Integer.parseInt(product[3]), Integer.parseInt(product[4]), 
						product[5], product[6], product[7]);
			}
			case "Gum": {
				sample = new Gum(product[1], Double.parseDouble(product[2]), 
						Integer.parseInt(product[3]), Integer.parseInt(product[4]), 
						product[5], product[6], Boolean.parseBoolean(product[7]));
			}
			case "Drink": {
				sample = new Drink(product[1], Double.parseDouble(product[2]), 
						Integer.parseInt(product[3]), Integer.parseInt(product[4]), 
						product[5], product[6], Integer.parseInt(product[7]));
			}
		}
		return sample;
	}
	public ArrayList<Product> getArrayList(){
		return products;
	}
}
