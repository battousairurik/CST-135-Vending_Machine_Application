package Vending_Machine;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class GlobalInventoryManagement {

	private File currentFile;
	
	// ArrayList of the ArrayList products
	private ArrayList<Dispenser> dispensers = new ArrayList<>();
	
	//Default Constructor to set existing File
	public GlobalInventoryManagement(){
		setDefaultFile();
		readFile();
	}
	//Constructor to set any File
	public GlobalInventoryManagement(File file){
		setFile(file);
		readFile();
	}
	//Method to set default File
	private void setDefaultFile (){
		currentFile = new File ("src\\machine1.csv");
	}
	//Method to set provided File
	public void setFile(File file){
		currentFile = file;
	}
	//Method to read contents of the File
	private void readFile (){
		
		ArrayList<Product> products = new ArrayList<>();
		
		try {
			Scanner inputStream = new Scanner (currentFile);
			
			while (inputStream.hasNext()){
				String data = inputStream.nextLine();
				String [] values = data.split(",");
				products.add(createEntry(values));
				
			}
			inputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		dispensers.add(new Dispenser(products));
	}
	//Create the ArrayList
	private Product createEntry (String [] product){
		String subClass = product[0];
		Product sample;
		switch (subClass) {
			default: 
			case "Candy": {
				sample = new Candy(product[1], Double.parseDouble(product[2]), 
						Integer.parseInt(product[3]), Integer.parseInt(product[4]), 
						product[5], product[6], Boolean.parseBoolean(product[7]));
				break;
			}
			case "Chips": {
				sample = new Chips(product[1], Double.parseDouble(product[2]), 
						Integer.parseInt(product[3]), Integer.parseInt(product[4]), 
						product[5], product[6], product[7]);
				break;
			}
			case "Gum": {
				sample = new Gum(product[1], Double.parseDouble(product[2]), 
						Integer.parseInt(product[3]), Integer.parseInt(product[4]), 
						product[5], product[6], Boolean.parseBoolean(product[7]));
				break;
			}
			case "Drink": {
				sample = new Drink(product[1], Double.parseDouble(product[2]), 
						Integer.parseInt(product[3]), Integer.parseInt(product[4]), 
						product[5], product[6], Integer.parseInt(product[7]));
				break;
			}
		}
		return sample;
	}
	
	public Dispenser getDispenser(int dispenserNumber)
	{
		if (dispenserNumber > dispensers.size())
			return null;
		
		return dispensers.get(dispenserNumber);
	}
	
	public ArrayList<Dispenser> getAllDispensers()
	{
		return dispensers;
	}
	
	public void sortItemsByName(int dispenserNumber)
	{
		if (dispenserNumber > dispensers.size())
			return;

		ArrayList<Product> tempProducts = dispensers.get(dispenserNumber).getArrayListOfProducts();
		tempProducts.sort(Comparator.comparing(Product::getProductName));
		Dispenser tempDispenser = new Dispenser(tempProducts);
		dispensers.set(dispenserNumber, tempDispenser);
	}
	
	public void sortItemsByQuantity(int dispenserNumber)
	{
		if (dispenserNumber > dispensers.size())
			return;

		ArrayList<Product> tempProducts = dispensers.get(dispenserNumber).getArrayListOfProducts();
		tempProducts.sort(Comparator.comparing(Product::getProductAmount));
		Dispenser tempDispenser = new Dispenser(tempProducts);
		dispensers.set(dispenserNumber, tempDispenser);
	}

	public String searchByProductName(ArrayList<Dispenser> dispensers, String searchTerms, int index, String log)
	{
		String result = "";
		
		for (int i = 0; i < dispensers.size(); i++)
		{
			if (index < dispensers.get(i).getTotalNumberOfProducts())
			{
				if (dispensers.get(i).getStockedProduct(index).getProductName().contains(searchTerms))
				{
					result = "Vending Machine #" + i + "\r\n";
					result += "Quantity: " + dispensers.get(i).getStockedProduct(index).getProductAmount() + "\r\n";
					result += "Location: " + dispensers.get(i).getStockedProduct(index).getProductLocation();
					
					log += "Found item at index " + index;
					
					// Creates searchLog.txt file
					createLog(log);
				}
				else
				{
					log += "Current dispenser: " + i;
					log += "  -  ";
					log += "Current index: " + index;
					log += "\r\n";
					
					result = searchByProductName(dispensers, searchTerms, index + 1, log);
				}
			}
		}
		
		return result;
	}
	
	private void createLog(String output)
	{
		String fileName = "searchLog.txt";
		try
		{
			PrintWriter printWriter = new PrintWriter(fileName);	
			printWriter.println(output);
			printWriter.close();
		}
		catch (FileNotFoundException e)
		{
			
		}
	}
}
