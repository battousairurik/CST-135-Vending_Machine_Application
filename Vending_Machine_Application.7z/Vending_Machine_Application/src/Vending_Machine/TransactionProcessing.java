package Vending_Machine;

import java.util.ArrayList;

public class TransactionProcessing
{
	private double moneyRemaining;
	private double moneySpent;
	private ArrayList<Product> transactionHistory = new ArrayList<>();
	
	public TransactionProcessing()
	{
		moneyRemaining = 0;
		moneySpent = 0;
	}
	
	public TransactionProcessing(double StartingMoney)
	{
		moneyRemaining = StartingMoney;
	}
	
	public double getMoneyRemaining()
	{
		return moneyRemaining;
	}
	
	public double getMoneySpent()
	{
		return moneySpent;
	}
	
	public boolean addTransaction(Product product)
	{
		if (moneyRemaining >= product.getProductPrice())
		{
			transactionHistory.add(product);
			moneySpent += product.getProductPrice();
			moneyRemaining -= product.getProductPrice();
			return true;
		}
		return false;
	}
	
	public ArrayList<Product> getTransactionHistory()
	{
		return transactionHistory;
	}
}
