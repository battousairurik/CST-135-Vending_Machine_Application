package Vending_Machine;

public class Candy extends Snack{

	private boolean isChocolate;
	
	//Default empty constructor
	public Candy()
	{
		setProductName("");
		setProductPrice(0.0);
		setProductID(-1);
		setProductAmount(0);
		setProductLocation("");
		setSnackBrand("");
		setIsChocolate(false);
		setIsStocked(false);
	}
	// Constructor for manual input
	public Candy (String name, Double price, int ID, int amount, String location, String brand, boolean choc){
		setProductName(name);
		setProductPrice(price);
		setProductID(ID);
		setProductAmount(amount);
		setProductLocation(location);
		setSnackBrand(brand);
		setIsChocolate(choc);
		if (amount > 0)
			setIsStocked(true);
		else
			setIsStocked(false);
	}
	
	// Copy constructor
	public Candy (Candy someCandy){
		setProductName(someCandy.getProductName());
		setProductPrice(someCandy.getProductPrice());
		setProductID(someCandy.getProductID());
		setProductAmount(someCandy.getProductAmount());
		setProductLocation(someCandy.getProductLocation());
		setSnackBrand(someCandy.getSnackBrand());
		setIsChocolate(someCandy.getIsChocolate());
		setIsStocked(someCandy.getIsStocked());
	}
	
	public void setIsChocolate (boolean value){
		isChocolate = value;
	}
	public boolean getIsChocolate (){
		return isChocolate;
	}
	// toString method to list all product information
	@Override
	public String toString (){
		return "Product: " + getProductName()
			+ "\nPrice: " + getProductPrice()
			+ "\nID: " + getProductID()
			+ "\nAmount: " + getProductAmount()
			+ "\nLocation: " + getProductLocation()
			+ "\nBrand: " + getSnackBrand()
			+ "\nChocolate: " + getIsChocolate()
			+ "\nStocked: " + getIsStocked();
	}
}
